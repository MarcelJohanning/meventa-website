"use strict";

const util = require("util");
const fs = require("fs");
const pathModule = require("path");
const crypto = require("crypto");

const PRINT_VERBOSE_SUMMARY = process.env.RUN_SUMMARY_VERBOSE === "1";
const PRINT_CYCLE_DETAILS = process.env.RUN_SUMMARY_CYCLES === "1";
const PRINT_LOCAL_OPEN_DETAILS = process.env.RUN_SUMMARY_LOCAL_OPEN === "1";
const PRINT_DIAGNOSTICS_DETAILS =
  process.env.RUN_SUMMARY_DIAGNOSTICS === "1" ||
  process.env.RUN_SUMMARY_VERBOSE === "1";

const EXPORT_HP2D_FOLD_ARTIFACT =
  process.env.RUN_SUMMARY_EXPORT_HP2D_FOLD === "1" ||
  process.env.RUN_SUMMARY_EXPORT_BEST_FOLD === "1";

const HP2D_FOLD_ARTIFACT_DIR =
  typeof process.env.RUN_SUMMARY_FOLD_ARTIFACT_DIR === "string" &&
  process.env.RUN_SUMMARY_FOLD_ARTIFACT_DIR.trim() !== ""
    ? process.env.RUN_SUMMARY_FOLD_ARTIFACT_DIR.trim()
    : null;

const INSPECT_OPTIONS = {
  depth: null,
  colors: false,
  compact: false,
  sorted: false,
  breakLength: 120
};

function printRunSummary(runStats) {
  if (!runStats || typeof runStats !== "object") {
    console.log("=== RUN SUMMARY ===");
    console.log("invalid runStats");
    console.log("=== END RUN SUMMARY ===");
    return;
  }

  const runMeta =
    runStats.runMeta && typeof runStats.runMeta === "object"
      ? runStats.runMeta
      : {};

  const problemMeta =
    runStats.problemMeta && typeof runStats.problemMeta === "object"
      ? runStats.problemMeta
      : {};

  const runOutcome =
    runStats.runOutcome && typeof runStats.runOutcome === "object"
      ? runStats.runOutcome
      : {};

  const bestResult =
    runStats.bestResult && typeof runStats.bestResult === "object"
      ? runStats.bestResult
      : null;

  const proposalClassSummary =
    runStats.proposalClassSummary &&
    typeof runStats.proposalClassSummary === "object" &&
    !Array.isArray(runStats.proposalClassSummary)
      ? runStats.proposalClassSummary
      : {};

  const rejectionSummary =
    runStats.rejectionSummary &&
    typeof runStats.rejectionSummary === "object" &&
    !Array.isArray(runStats.rejectionSummary)
      ? runStats.rejectionSummary
      : {};

  const centerAdmissionStats =
    runStats.centerAdmissionStats &&
    typeof runStats.centerAdmissionStats === "object" &&
    !Array.isArray(runStats.centerAdmissionStats)
      ? runStats.centerAdmissionStats
      : {};

  const loeProvenanceSummary =
    runStats.loeProvenanceSummary &&
    typeof runStats.loeProvenanceSummary === "object" &&
    !Array.isArray(runStats.loeProvenanceSummary)
      ? runStats.loeProvenanceSummary
      : {};

  const diagnostics =
    runStats.diagnostics &&
    typeof runStats.diagnostics === "object" &&
    !Array.isArray(runStats.diagnostics)
      ? runStats.diagnostics
      : {};

  const cycleSummary = Array.isArray(runStats.cycleSummary)
    ? runStats.cycleSummary
    : [];

  const localOpenQuality =
    runStats.localOpenQuality &&
    typeof runStats.localOpenQuality === "object" &&
    !Array.isArray(runStats.localOpenQuality)
      ? runStats.localOpenQuality
      : {};

  const localOpenTotals =
    localOpenQuality.totals &&
    typeof localOpenQuality.totals === "object" &&
    !Array.isArray(localOpenQuality.totals)
      ? localOpenQuality.totals
      : {};

  const localOpenFiltering =
    localOpenQuality.filtering &&
    typeof localOpenQuality.filtering === "object" &&
    !Array.isArray(localOpenQuality.filtering)
      ? localOpenQuality.filtering
      : {};

  const localOpenPerSource =
    localOpenQuality.perSourceCenter &&
    typeof localOpenQuality.perSourceCenter === "object" &&
    !Array.isArray(localOpenQuality.perSourceCenter)
      ? localOpenQuality.perSourceCenter
      : {};

  const compactBest = buildCompactBestResult(bestResult);
  const compactCycles = buildCompactCycleSummary(cycleSummary);
  const mainRejectionReason = getMainRejectionReason(rejectionSummary);
  const centerSummary = buildCenterSummary(runStats);
  const compactLoeProvenance =
    buildCompactLoeProvenanceSummary(loeProvenanceSummary);
  const compactDiagnostics =
    buildCompactDiagnosticsSummary(diagnostics);

  console.log("=== RUN SUMMARY ===");

  printSummarySection("PROBLEM", {
    id: problemMeta.problemId || null,
    type: problemMeta.problemType || null,
    benchmarkId: problemMeta.benchmarkId || null,
    sequenceLength: toSafeIntegerOrNull(problemMeta.sequenceLength)
  });

  printSummarySection("RUN", {
    durationMs: toSafeIntegerOrNull(runMeta.durationMs),
    maxCyclesConfigured: toSafeIntegerOrNull(runMeta.maxCyclesConfigured),
    executedCycles: toSafeIntegerOrNull(runMeta.executedCycles),
    terminatedBy: runMeta.terminatedBy || "unknown"
  });

  printSummarySection("OUTCOME", {
    initialPointCount: toSafeInteger(runOutcome.initialPointCount),
    finalPointCount: toSafeInteger(runOutcome.finalPointCount),
    pointDeltaTotal: toSafeInteger(runOutcome.pointDeltaTotal),
    productiveCycles: compactCycles.productiveCycles,
    zeroDeltaCycles: compactCycles.zeroDeltaCycles,
    plateauFromCycle: compactCycles.plateauFromCycle
  });

  printSummarySection("BEST HP2D RESULT", compactBest);

  const bestFoldArtifact = buildBestHP2DFoldArtifact({
    runStats,
    bestResult,
    problemMeta,
    compactBest
  });

  if (bestFoldArtifact) {
    printSummarySection("BEST HP2D FOLD ARTIFACT", bestFoldArtifact);

    if (EXPORT_HP2D_FOLD_ARTIFACT) {
      writeBestHP2DFoldArtifact(bestFoldArtifact);
    }
  }

  printSummarySection(
    "PROPOSALS",
    buildCompactProposalSummary(proposalClassSummary)
  );

  printSummarySection("REJECTIONS", {
    totalRejectedCount: toSafeInteger(rejectionSummary.totalRejectedCount),
    mainReason: mainRejectionReason.reason,
    mainReasonCount: mainRejectionReason.count,
    byReason: cloneNumberMap(rejectionSummary.byReason)
  });

  printSummarySection(
    "CENTER ADMISSION",
    buildCompactCenterAdmissionSummary(centerAdmissionStats)
  );

  printSummarySection("CENTER SUMMARY", centerSummary);

  printSummarySection("LOE PROVENANCE", compactLoeProvenance);

  printSummarySection("DIAGNOSTICS", compactDiagnostics);

  printSummarySection("CYCLES", {
    firstCycle: compactCycles.firstCycle,
    lastProductiveCycle: compactCycles.lastProductiveCycle,
    lastCycle: compactCycles.lastCycle
  });

  if (PRINT_CYCLE_DETAILS || PRINT_VERBOSE_SUMMARY) {
    console.log("");
    console.log("CYCLE DETAILS");
    printCycleDetails(cycleSummary);
  }

  if (PRINT_LOCAL_OPEN_DETAILS || PRINT_VERBOSE_SUMMARY) {
    console.log("");
    console.log("LOCAL_OPEN QUALITY");
    printLocalOpenQuality({
      proposalClassSummary,
      totals: localOpenTotals,
      filtering: localOpenFiltering,
      perSourceCenter: localOpenPerSource
    });
  }

  if (PRINT_DIAGNOSTICS_DETAILS) {
    console.log("");
    console.log("DIAGNOSTICS DETAILS");
    printDiagnosticsDetails(diagnostics);
  }

  if (PRINT_VERBOSE_SUMMARY) {
    console.log("");
    console.log("VERBOSE META");
    printSummarySection("problem:", {
      id: problemMeta.problemId || null,
      type: problemMeta.problemType || null,
      benchmarkId: problemMeta.benchmarkId || null,
      sequenceLength: toSafeIntegerOrNull(problemMeta.sequenceLength),
      sequence: problemMeta.sequence || null,
      reference:
        problemMeta.reference && typeof problemMeta.reference === "object"
          ? problemMeta.reference
          : null
    });

    printSummarySection("run:", {
      startedAt: runMeta.startedAt || null,
      finishedAt: runMeta.finishedAt || null,
      durationMs: toSafeIntegerOrNull(runMeta.durationMs),
      maxCyclesConfigured: toSafeIntegerOrNull(runMeta.maxCyclesConfigured),
      executedCycles: toSafeIntegerOrNull(runMeta.executedCycles),
      terminatedBy: runMeta.terminatedBy || "unknown"
    });
  }

  console.log("=== END RUN SUMMARY ===");
}

function printSummarySection(label, value) {
  console.log(`${label} ${formatForSummary(value)}`);
}

function formatForSummary(value) {
  return util.inspect(value, INSPECT_OPTIONS);
}

function buildCompactBestResult(bestResult) {
  if (!bestResult) {
    return {
      status: "none",
      energy: null,
      knownBestEnergy: null,
      gapToKnownBest: null,
      valid: null,
      sequenceLength: null,
      movesLength: 0,
      coordsLength: 0,
      provenance: null
    };
  }

  const resultView =
    bestResult.resultView && typeof bestResult.resultView === "object"
      ? bestResult.resultView
      : {};

  const comparison =
    bestResult.comparison && typeof bestResult.comparison === "object"
      ? bestResult.comparison
      : {};

  const display =
    resultView.display && typeof resultView.display === "object"
      ? resultView.display
      : {};

  const moves = Array.isArray(display.moves) ? display.moves : [];
  const coords = Array.isArray(display.coords) ? display.coords : [];

  return {
    status: bestResult.interpretationStatus || null,
    kind: resultView.kind || null,
    candidateType: resultView.candidateType || null,
    valid: toBooleanOrNull(resultView.valid),
    sequenceLength: toSafeIntegerOrNull(resultView.sequenceLength),
    objective: comparison.objective || null,
    energy: toSafeNumberOrNull(comparison.primaryValue),
    secondaryValue: toSafeNumberOrNull(comparison.secondaryValue),
    knownBestEnergy: toSafeNumberOrNull(
      comparison.knownBestEnergy ?? comparison.knownBestValue
    ),
    gapToKnownBest: toSafeNumberOrNull(comparison.gapToKnownBest),
    movesLength: moves.length,
    coordsLength: coords.length,
    improvedAtCycle: toSafeIntegerOrNull(bestResult.improvedAtCycle),
    improvedAtPointCount: toSafeIntegerOrNull(bestResult.improvedAtPointCount),
    provenance: buildCompactBestProvenance(bestResult.provenance)
  };
}

function buildCompactBestProvenance(provenance) {
  if (
    !provenance ||
    typeof provenance !== "object" ||
    Array.isArray(provenance)
  ) {
    return null;
  }

  return {
    candidateId: provenance.candidateId || null,
    candidateKind: provenance.candidateKind || null,
    candidateStatus: provenance.candidateStatus || null,
    proposalClass: provenance.proposalClass || null,
    openingType: provenance.openingType || null,
    sourcePointId: provenance.sourcePointId || null,
    sourceType: provenance.sourceType || null,
    strongestScaleType: provenance.strongestScaleType || null,
    primitiveScaleType: provenance.primitiveScaleType || null,
    acceptedAtCycle: toSafeIntegerOrNull(provenance.acceptedAtCycle),
    operatorFamily: provenance.operatorFamily || null,
    hasProblemCandidate: provenance.hasProblemCandidate === true,
    hasCandidateState: provenance.hasCandidateState === true,
    pairMeta: compactPairMeta(provenance.pairMeta)
  };
}

function compactPairMeta(pairMeta) {
  if (!pairMeta || typeof pairMeta !== "object" || Array.isArray(pairMeta)) {
    return null;
  }

  return {
    interiorScore: toSafeNumberOrNull(pairMeta.interiorScore),
    scaleCompatibility: toSafeNumberOrNull(pairMeta.scaleCompatibility),
    sourceType: pairMeta.sourceType || null,
    strongestScaleType: pairMeta.strongestScaleType || null,
    primitiveScaleType: pairMeta.primitiveScaleType || null
  };
}

function buildCompactProposalSummary(proposalClassSummary) {
  const orderedKeys = Object.keys(proposalClassSummary).sort(
    compareProposalClassKeys
  );

  if (orderedKeys.length === 0) {
    return {};
  }

  const out = {};

  for (const key of orderedKeys) {
    const stats = proposalClassSummary[key] || {};

    out[key] = {
      submitted: toSafeInteger(stats.rawCount),
      realized: toSafeInteger(stats.realizedCount),
      accepted: toSafeInteger(stats.acceptedCount),
      rejected: toSafeInteger(stats.rejectedCount),
      delta: roundNumber(stats.acceptedPointDelta)
    };
  }

  return out;
}

function buildCompactCenterAdmissionSummary(centerAdmissionStats) {
  if (
    !centerAdmissionStats ||
    typeof centerAdmissionStats !== "object" ||
    Array.isArray(centerAdmissionStats)
  ) {
    return {
      admitted: 0,
      rejected: 0,
      byOpeningType: {},
      rejectionReasons: {}
    };
  }

  return {
    submitted: toSafeInteger(centerAdmissionStats.submitted),
    admitted: toSafeInteger(centerAdmissionStats.admitted),
    rejected: toSafeInteger(centerAdmissionStats.rejected),
    byOpeningType: cloneNestedCenterAdmissionMap(
      centerAdmissionStats.byOpeningType
    ),
    rejectionReasons: cloneNumberMap(centerAdmissionStats.rejectionReasons)
  };
}

function buildCompactLoeProvenanceSummary(loeProvenanceSummary) {
  const localOpen =
    loeProvenanceSummary &&
    typeof loeProvenanceSummary === "object" &&
    !Array.isArray(loeProvenanceSummary) &&
    loeProvenanceSummary.localOpen &&
    typeof loeProvenanceSummary.localOpen === "object" &&
    !Array.isArray(loeProvenanceSummary.localOpen)
      ? loeProvenanceSummary.localOpen
      : null;

  if (!localOpen) {
    return {
      localOpen: {
        totals: createEmptyLoeOutcomeRow(),
        bySourceType: {},
        byStrongestScaleType: {},
        byPrimitiveScaleType: {},
        mixPair: createEmptyLoeMixPairRow()
      }
    };
  }

  return {
    localOpen: {
      totals: cloneLoeOutcomeBucket(localOpen.totals),
      bySourceType: cloneLoeOutcomeBucketMap(localOpen.bySourceType),
      byStrongestScaleType: cloneLoeOutcomeBucketMap(
        localOpen.byStrongestScaleType
      ),
      byPrimitiveScaleType: cloneLoeOutcomeBucketMap(
        localOpen.byPrimitiveScaleType
      ),
      mixPair: cloneLoeMixPairStats(localOpen.mixPair)
    }
  };
}

function createEmptyLoeOutcomeRow() {
  return {
    realized: 0,
    accepted: 0,
    rejected: 0,
    duplicateRejected: 0,
    acceptanceRate: 0,
    duplicateRate: 0
  };
}

function createEmptyLoeMixPairRow() {
  return {
    realized: 0,
    accepted: 0,
    rejected: 0,
    duplicateRejected: 0,
    acceptanceRate: 0,
    duplicateRate: 0,
    avgInteriorScore: 0,
    avgScaleCompatibility: 0
  };
}

function cloneLoeOutcomeBucket(bucket) {
  const realized = toSafeInteger(bucket?.realizedCount);
  const accepted = toSafeInteger(bucket?.acceptedCount);
  const rejected = toSafeInteger(bucket?.rejectedCount);
  const duplicateRejected = toSafeInteger(bucket?.duplicateRejectedCount);

  return {
    realized,
    accepted,
    rejected,
    duplicateRejected,
    acceptanceRate:
      realized > 0
        ? roundNumber(accepted / realized)
        : 0,
    duplicateRate:
      rejected > 0
        ? roundNumber(duplicateRejected / rejected)
        : 0
  };
}

function cloneLoeOutcomeBucketMap(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }

  const out = {};

  for (const [key, bucket] of Object.entries(value)) {
    out[key] = cloneLoeOutcomeBucket(bucket);
  }

  return sortObjectByPreferredLoeKeys(out);
}

function cloneLoeMixPairStats(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return createEmptyLoeMixPairRow();
  }

  const realized = toSafeInteger(value.realizedCount);
  const accepted = toSafeInteger(value.acceptedCount);
  const rejected = toSafeInteger(value.rejectedCount);
  const duplicateRejected = toSafeInteger(value.duplicateRejectedCount);

  return {
    realized,
    accepted,
    rejected,
    duplicateRejected,
    acceptanceRate:
      realized > 0
        ? roundNumber(accepted / realized)
        : 0,
    duplicateRate:
      rejected > 0
        ? roundNumber(duplicateRejected / rejected)
        : 0,
    avgInteriorScore: roundNumber(value.avgInteriorScore),
    avgScaleCompatibility: roundNumber(value.avgScaleCompatibility)
  };
}

function sortObjectByPreferredLoeKeys(value) {
  const preferredOrder = [
    "direct",
    "mix",
    "bootstrap",
    "micro",
    "small",
    "medium",
    "large",
    "wide",
    "hyperball",
    "unknown"
  ];

  const out = {};

  for (const key of preferredOrder) {
    if (Object.prototype.hasOwnProperty.call(value, key)) {
      out[key] = value[key];
    }
  }

  const remainingKeys = Object.keys(value)
    .filter((key) => !Object.prototype.hasOwnProperty.call(out, key))
    .sort();

  for (const key of remainingKeys) {
    out[key] = value[key];
  }

  return out;
}

function buildCompactDiagnosticsSummary(diagnostics) {
  if (
    !diagnostics ||
    typeof diagnostics !== "object" ||
    Array.isArray(diagnostics)
  ) {
    return createEmptyDiagnosticsSummary();
  }

  const liveBest =
    diagnostics.liveBest &&
    typeof diagnostics.liveBest === "object" &&
    !Array.isArray(diagnostics.liveBest)
      ? diagnostics.liveBest
      : {};

  const perf =
    diagnostics.perf &&
    typeof diagnostics.perf === "object" &&
    !Array.isArray(diagnostics.perf)
      ? diagnostics.perf
      : {};

  const checkpoints = Array.isArray(perf.checkpoints)
    ? perf.checkpoints
    : [];

  const externalPauseCandidates = Array.isArray(perf.externalPauseCandidates)
    ? perf.externalPauseCandidates
    : [];

  const realizationSpikes = Array.isArray(perf.realizationSpikes)
    ? perf.realizationSpikes
    : [];

  const latestCheckpoint =
    checkpoints.length > 0
      ? checkpoints[checkpoints.length - 1]
      : null;

  const latestLiveBestEvents = Array.isArray(liveBest.history)
    ? liveBest.history.slice(-5).map(compactLiveBestHistoryEntry)
    : [];

  return {
    liveBest: {
      improvementCount: toSafeInteger(liveBest.improvementCount),
      lastPrintedCycle: toSafeIntegerOrNull(liveBest.lastPrintedCycle),
      recentEvents: latestLiveBestEvents
    },
    perf: {
      checkpointCount: checkpoints.length,
      latestCheckpoint: compactPerfCheckpoint(latestCheckpoint),
      externalPauseCandidateCount: externalPauseCandidates.length,
      latestExternalPauseCandidates:
        externalPauseCandidates.slice(-5).map(compactExternalPauseCandidate),
      realizationSpikeCount: realizationSpikes.length,
      latestRealizationSpikes:
        realizationSpikes.slice(-5).map(compactRealizationSpike)
    }
  };
}

function createEmptyDiagnosticsSummary() {
  return {
    liveBest: {
      improvementCount: 0,
      lastPrintedCycle: null,
      recentEvents: []
    },
    perf: {
      checkpointCount: 0,
      latestCheckpoint: null,
      externalPauseCandidateCount: 0,
      latestExternalPauseCandidates: [],
      realizationSpikeCount: 0,
      latestRealizationSpikes: []
    }
  };
}

function compactLiveBestHistoryEntry(entry) {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    return null;
  }

  return {
    type: entry.type || "checkpoint",
    cycle: toSafeIntegerOrNull(entry.cycle),
    points: toSafeIntegerOrNull(entry.points),
    bestEnergy: toSafeNumberOrNull(entry.bestEnergy),
    bestSecondaryValue: toSafeNumberOrNull(entry.bestSecondaryValue),
    objective: entry.objective || null,
    candidateId: entry.candidateId || null,
    proposalClass: entry.proposalClass || null,
    openingType: entry.openingType || null,
    sourceType: entry.sourceType || null,
    strongestScaleType: entry.strongestScaleType || null,
    primitiveScaleType: entry.primitiveScaleType || null,
    pairMeta: compactPairMeta(entry.pairMeta)
  };
}

function compactPerfCheckpoint(checkpoint) {
  if (!checkpoint || typeof checkpoint !== "object" || Array.isArray(checkpoint)) {
    return null;
  }

  return {
    fromCycle: toSafeIntegerOrNull(checkpoint.fromCycle),
    toCycle: toSafeIntegerOrNull(checkpoint.toCycle),
    cycles: toSafeInteger(checkpoint.cycles),

    avgTotalMs: roundNumber(checkpoint.avgTotalMs),
    maxTotalMs: roundNumber(checkpoint.maxTotalMs),

    avgBuildProposalsMs: roundNumber(checkpoint.avgBuildProposalsMs),
    maxBuildProposalsMs: roundNumber(checkpoint.maxBuildProposalsMs),

    avgUpdateConflictSpaceMs: roundNumber(checkpoint.avgUpdateConflictSpaceMs),
    maxUpdateConflictSpaceMs: roundNumber(checkpoint.maxUpdateConflictSpaceMs),

    avgRealizationMs: roundNumber(checkpoint.avgRealizationMs),
    maxRealizationMs: roundNumber(checkpoint.maxRealizationMs),

    avgLoeMs: roundNumber(checkpoint.avgLoeMs),
    maxLoeMs: roundNumber(checkpoint.maxLoeMs),

    avgTargetSelectionMs: roundNumber(checkpoint.avgTargetSelectionMs),
    maxTargetSelectionMs: roundNumber(checkpoint.maxTargetSelectionMs),

    avgSourceFeedbackMs: roundNumber(checkpoint.avgSourceFeedbackMs),
    maxSourceFeedbackMs: roundNumber(checkpoint.maxSourceFeedbackMs),

    externalPauseCandidateCount: Array.isArray(checkpoint.externalPauseCandidates)
      ? checkpoint.externalPauseCandidates.length
      : 0
  };
}

function compactExternalPauseCandidate(entry) {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    return null;
  }

  return {
    cycle: toSafeIntegerOrNull(entry.cycle),
    pointCount: toSafeIntegerOrNull(entry.pointCount),
    totalMs: roundNumber(entry.totalMs),
    dominantField: entry.dominantField || null,
    dominantMs: roundNumber(entry.dominantMs),
    reason: entry.reason || "external_pause_candidate"
  };
}

function compactRealizationSpike(entry) {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    return null;
  }

  return {
    cycle: toSafeIntegerOrNull(entry.cycle),
    pointCount: toSafeIntegerOrNull(entry.pointCount),
    realizationMs: roundNumber(entry.realizationMs),
    rollingAvgBeforeMs: toSafeNumberOrNull(entry.rollingAvgBeforeMs),
    thresholdMs: roundNumber(entry.thresholdMs),
    factor: roundNumber(entry.factor),
    totalMs: roundNumber(entry.totalMs),
    proposalCount: toSafeInteger(entry.proposalCount),
    candidateCount: toSafeInteger(entry.candidateCount),
    acceptedCount: toSafeInteger(entry.acceptedCount),
    rejectedCount: toSafeInteger(entry.rejectedCount),
    proposalTypes: cloneNumberMap(entry.proposalTypes),
    sourceTypeCounts: cloneNumberMap(entry.sourceTypeCounts),
    strongestScaleTypeCounts: cloneNumberMap(entry.strongestScaleTypeCounts),
    primitiveScaleTypeCounts: cloneNumberMap(entry.primitiveScaleTypeCounts),
    pairMetaSummary: clonePlainObject(entry.pairMetaSummary),
    operatorFamilyCounts: cloneNumberMap(entry.operatorFamilyCounts)
  };
}

function printDiagnosticsDetails(diagnostics) {
  if (
    !diagnostics ||
    typeof diagnostics !== "object" ||
    Array.isArray(diagnostics)
  ) {
    console.log("none");
    return;
  }

  const perf =
    diagnostics.perf &&
    typeof diagnostics.perf === "object" &&
    !Array.isArray(diagnostics.perf)
      ? diagnostics.perf
      : {};

  const liveBest =
    diagnostics.liveBest &&
    typeof diagnostics.liveBest === "object" &&
    !Array.isArray(diagnostics.liveBest)
      ? diagnostics.liveBest
      : {};

  const liveBestHistory = Array.isArray(liveBest.history)
    ? liveBest.history
    : [];

  const checkpoints = Array.isArray(perf.checkpoints)
    ? perf.checkpoints
    : [];

  const externalPauseCandidates = Array.isArray(perf.externalPauseCandidates)
    ? perf.externalPauseCandidates
    : [];

  const realizationSpikes = Array.isArray(perf.realizationSpikes)
    ? perf.realizationSpikes
    : [];

  printSummarySection(
    "liveBestHistory:",
    liveBestHistory.slice(-20).map(compactLiveBestHistoryEntry)
  );

  printSummarySection(
    "perfCheckpoints:",
    checkpoints.slice(-20).map(compactPerfCheckpoint)
  );

  printSummarySection(
    "externalPauseCandidates:",
    externalPauseCandidates.slice(-20).map(compactExternalPauseCandidate)
  );

  printSummarySection(
    "realizationSpikes:",
    realizationSpikes.slice(-20).map(compactRealizationSpike)
  );
}

function buildCompactCycleSummary(cycleSummary) {
  const cycles = Array.isArray(cycleSummary) ? cycleSummary : [];

  if (cycles.length === 0) {
    return {
      productiveCycles: 0,
      zeroDeltaCycles: 0,
      plateauFromCycle: null,
      firstCycle: null,
      lastProductiveCycle: null,
      lastCycle: null
    };
  }

  let productiveCycles = 0;
  let zeroDeltaCycles = 0;
  let lastProductiveCycle = null;
  let plateauFromCycle = null;
  let currentZeroRunStart = null;

  for (const cycle of cycles) {
    const cycleNumber = toSafeInteger(cycle?.cycleIndex) + 1;
    const pointDelta = toSafeInteger(cycle?.pointDelta);

    if (pointDelta > 0) {
      productiveCycles += 1;
      lastProductiveCycle = cycleNumber;
      currentZeroRunStart = null;
    } else {
      zeroDeltaCycles += 1;

      if (currentZeroRunStart === null) {
        currentZeroRunStart = cycleNumber;
      }
    }
  }

  if (currentZeroRunStart !== null) {
    plateauFromCycle = currentZeroRunStart;
  }

  return {
    productiveCycles,
    zeroDeltaCycles,
    plateauFromCycle,
    firstCycle: buildCompactCycleRow(cycles[0]),
    lastProductiveCycle:
      lastProductiveCycle !== null
        ? buildCompactCycleRow(cycles[lastProductiveCycle - 1])
        : null,
    lastCycle: buildCompactCycleRow(cycles[cycles.length - 1])
  };
}

function buildCompactCycleRow(cycle) {
  if (!cycle || typeof cycle !== "object") {
    return null;
  }

  return {
    cycle: toSafeInteger(cycle.cycleIndex) + 1,
    before: toSafeInteger(cycle.pointCountBefore),
    after: toSafeInteger(cycle.pointCountAfter),
    delta: toSafeInteger(cycle.pointDelta),
    accepted: toSafeInteger(cycle.acceptedCount),
    rejected: toSafeInteger(cycle.rejectedCount),
    proposalClasses: cloneNumberMap(cycle.proposalClasses),
    acceptedByClass: cloneNumberMap(cycle.acceptedByProposalClass),
    rejectedByClass: cloneNumberMap(cycle.rejectedByProposalClass)
  };
}

function buildCenterSummary(runStats) {
  const explicitSummary = getExplicitCenterSummary(runStats);

  if (explicitSummary) {
    return normalizeExplicitCenterSummary(explicitSummary);
  }

  const points = collectFinalPointsFromRunStats(runStats);

  if (points.length === 0) {
    return createEmptyCenterSummary("no_center_data_in_run_stats");
  }

  return buildCenterSummaryFromPoints(points);
}

function getExplicitCenterSummary(runStats) {
  const candidates = [
    runStats?.centerSummary,
    runStats?.centerLifecycleSummary,
    runStats?.explorationCenterSummary,
    runStats?.centerStats
  ];

  for (const candidate of candidates) {
    if (
      candidate &&
      typeof candidate === "object" &&
      !Array.isArray(candidate)
    ) {
      return candidate;
    }
  }

  return null;
}

function normalizeExplicitCenterSummary(summary) {
  const out = createEmptyCenterSummary("explicit");

  out.explorationCenterCount = toSafeInteger(
    summary.explorationCenterCount ??
    summary.centerCount ??
    summary.totalCenters
  );

  out.probationaryCount = toSafeInteger(summary.probationaryCount);
  out.activeCount = toSafeInteger(summary.activeCount);
  out.sterileCount = toSafeInteger(summary.sterileCount);
  out.retiredCount = toSafeInteger(summary.retiredCount);
  out.unknownStatusCount = toSafeInteger(summary.unknownStatusCount);

  out.totalProbationUsed = toSafeInteger(
    summary.totalProbationUsed ??
    summary.probationUsed
  );

  out.totalProbationBudget = toSafeInteger(
    summary.totalProbationBudget ??
    summary.probationBudget
  );

  out.remainingProbationBudget =
    Math.max(0, out.totalProbationBudget - out.totalProbationUsed);

  out.totalAcceptedChildren = toSafeInteger(
    summary.totalAcceptedChildren ??
    summary.acceptedChildren
  );

  out.totalDuplicateChildren = toSafeInteger(
    summary.totalDuplicateChildren ??
    summary.duplicateChildren
  );

  out.totalInvalidChildren = toSafeInteger(
    summary.totalInvalidChildren ??
    summary.invalidChildren
  );

  out.totalOtherRejectedChildren = toSafeInteger(
    summary.totalOtherRejectedChildren ??
    summary.otherRejectedChildren
  );

  out.avgAcceptedChildrenPerCenter =
    toSafeNumberOrNull(summary.avgAcceptedChildrenPerCenter) ??
    computeAverage(out.totalAcceptedChildren, out.explorationCenterCount);

  out.avgDuplicateRate =
    toSafeNumberOrNull(summary.avgDuplicateRate) ??
    computeDuplicateRate({
      duplicateChildren: out.totalDuplicateChildren,
      acceptedChildren: out.totalAcceptedChildren,
      invalidChildren: out.totalInvalidChildren,
      otherRejectedChildren: out.totalOtherRejectedChildren
    });

  out.bestCenterChildPrimaryValue =
    toSafeNumberOrNull(
      summary.bestCenterChildPrimaryValue ??
      summary.bestChildPrimaryValue
    );

  out.centersWithAcceptedChildren = toSafeInteger(
    summary.centersWithAcceptedChildren
  );

  out.centersWithCompletedProbation = toSafeInteger(
    summary.centersWithCompletedProbation
  );

  out.budgetDiagnostics = cloneBudgetDiagnostics(summary.budgetDiagnostics);

  out.source = "explicit";

  return out;
}

function buildCenterSummaryFromPoints(points) {
  const summary = createEmptyCenterSummary("points");

  for (const point of points) {
    if (!isExplorationCenterPoint(point)) {
      continue;
    }

    summary.explorationCenterCount += 1;

    const status = getCenterStatus(point);

    if (status === "probationary") {
      summary.probationaryCount += 1;
    } else if (status === "active") {
      summary.activeCount += 1;
    } else if (status === "sterile") {
      summary.sterileCount += 1;
    } else if (status === "retired") {
      summary.retiredCount += 1;
    } else {
      summary.unknownStatusCount += 1;
    }

    const probation = getProbationObjectFromPoint(point);

    const budget = toSafeInteger(probation?.budget);
    const used = toSafeInteger(probation?.used);
    const acceptedChildren = toSafeInteger(probation?.acceptedChildren);
    const duplicateChildren = toSafeInteger(probation?.duplicateChildren);
    const invalidChildren = toSafeInteger(probation?.invalidChildren);
    const otherRejectedChildren = toSafeInteger(probation?.otherRejectedChildren);

    summary.totalProbationBudget += budget;
    summary.totalProbationUsed += used;
    summary.totalAcceptedChildren += acceptedChildren;
    summary.totalDuplicateChildren += duplicateChildren;
    summary.totalInvalidChildren += invalidChildren;
    summary.totalOtherRejectedChildren += otherRejectedChildren;

    if (acceptedChildren > 0) {
      summary.centersWithAcceptedChildren += 1;
    }

    if (budget > 0 && used >= budget) {
      summary.centersWithCompletedProbation += 1;
    }

    const bestChildPrimaryValue =
      Number.isFinite(probation?.bestChildPrimaryValue)
        ? probation.bestChildPrimaryValue
        : null;

    if (Number.isFinite(bestChildPrimaryValue)) {
      summary.bestCenterChildPrimaryValue =
        selectLowerNumber(
          summary.bestCenterChildPrimaryValue,
          bestChildPrimaryValue
        );
    }
  }

  summary.remainingProbationBudget =
    Math.max(0, summary.totalProbationBudget - summary.totalProbationUsed);

  summary.avgAcceptedChildrenPerCenter =
    computeAverage(
      summary.totalAcceptedChildren,
      summary.explorationCenterCount
    );

  summary.avgDuplicateRate =
    computeDuplicateRate({
      duplicateChildren: summary.totalDuplicateChildren,
      acceptedChildren: summary.totalAcceptedChildren,
      invalidChildren: summary.totalInvalidChildren,
      otherRejectedChildren: summary.totalOtherRejectedChildren
    });

  return summary;
}

function createEmptyCenterSummary(source) {
  return {
    source,
    explorationCenterCount: 0,
    probationaryCount: 0,
    activeCount: 0,
    sterileCount: 0,
    retiredCount: 0,
    unknownStatusCount: 0,

    totalProbationUsed: 0,
    totalProbationBudget: 0,
    remainingProbationBudget: 0,

    totalAcceptedChildren: 0,
    totalDuplicateChildren: 0,
    totalInvalidChildren: 0,
    totalOtherRejectedChildren: 0,

    centersWithAcceptedChildren: 0,
    centersWithCompletedProbation: 0,

    avgAcceptedChildrenPerCenter: 0,
    avgDuplicateRate: 0,
    bestCenterChildPrimaryValue: null,

    budgetDiagnostics: createEmptyBudgetDiagnostics()
  };
}

function createEmptyBudgetDiagnostics() {
  return {
    totalCenters: 0,
    completedProbationCenters: 0,
    incompleteProbationCenters: 0,

    completedWithAcceptedChildren: 0,
    completedWithoutAcceptedChildren: 0,
    completedWithLowDuplicateRate: 0,
    completedWithHighDuplicateRate: 0,

    incompleteWithAcceptedChildren: 0,
    incompleteWithoutAcceptedChildren: 0,

    avgBudget: 0,
    avgUsed: 0,
    avgRemaining: 0,
    avgAcceptedChildrenWhenCompleted: 0,
    avgDuplicateRateWhenCompleted: 0,

    bestCompletedCenterChildPrimaryValue: null,
    bestIncompleteCenterChildPrimaryValue: null,

    byOpeningType: {
      local: createEmptyBudgetOpeningTypeStats(),
      jump: createEmptyBudgetOpeningTypeStats(),
      deep_jump: createEmptyBudgetOpeningTypeStats(),
      unknown: createEmptyBudgetOpeningTypeStats()
    },

    topBudgetLimitedCenters: []
  };
}

function createEmptyBudgetOpeningTypeStats() {
  return {
    centers: 0,
    probationary: 0,
    active: 0,
    sterile: 0,
    retired: 0,
    unknownStatus: 0,

    completed: 0,
    incomplete: 0,

    completedWithAcceptedChildren: 0,
    incompleteWithAcceptedChildren: 0,

    totalBudget: 0,
    totalUsed: 0,
    totalRemaining: 0,

    acceptedChildren: 0,
    duplicateChildren: 0,
    invalidChildren: 0,
    otherRejectedChildren: 0,

    avgBudget: 0,
    avgUsed: 0,
    avgRemaining: 0,
    avgAcceptedChildren: 0,
    duplicateRate: 0,

    bestChildPrimaryValue: null,
    bestCompletedChildPrimaryValue: null,
    bestIncompleteChildPrimaryValue: null
  };
}

function cloneBudgetDiagnostics(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return createEmptyBudgetDiagnostics();
  }

  const cloned = clonePlainObject(value);

  if (!cloned || typeof cloned !== "object" || Array.isArray(cloned)) {
    return createEmptyBudgetDiagnostics();
  }

  return cloned;
}

function collectFinalPointsFromRunStats(runStats) {
  const candidates = [
    runStats?.finalState?.points,
    runStats?.finalConflictSpaceState?.points,
    runStats?.conflictSpaceState?.points,
    runStats?.state?.points,
    runStats?.latestState?.points,
    runStats?.lastState?.points,
    runStats?.finalPoints,
    runStats?.points
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) {
      return candidate;
    }
  }

  const mapCandidates = [
    runStats?.finalState?.pointMap,
    runStats?.finalConflictSpaceState?.pointMap,
    runStats?.conflictSpaceState?.pointMap,
    runStats?.state?.pointMap,
    runStats?.latestState?.pointMap,
    runStats?.lastState?.pointMap,
    runStats?.pointMap
  ];

  for (const candidate of mapCandidates) {
    if (candidate instanceof Map) {
      return Array.from(candidate.values());
    }
  }

  return [];
}

function isExplorationCenterPoint(point) {
  const role =
    firstString(
      point?.role,
      point?.meta?.role,
      point?.payload?.candidateState?.role,
      point?.payload?.candidateState?.centerMeta?.role,
      point?.centerMeta?.role,
      point?.meta?.centerMeta?.role
    );

  const admissionRole =
    firstString(
      point?.admissionRole,
      point?.meta?.admissionRole,
      point?.payload?.candidateState?.admissionRole,
      point?.payload?.candidateState?.centerMeta?.admissionRole,
      point?.centerMeta?.admissionRole,
      point?.meta?.centerMeta?.admissionRole
    );

  return (
    role === "exploration_center" &&
    admissionRole === "center_opening"
  );
}

function getCenterStatus(point) {
  return firstString(
    point?.centerStatus,
    point?.meta?.centerStatus,
    point?.payload?.candidateState?.centerStatus,
    point?.payload?.candidateState?.centerMeta?.centerStatus,
    point?.centerMeta?.centerStatus,
    point?.meta?.centerMeta?.centerStatus
  ) || "unknown";
}

function getProbationObjectFromPoint(point) {
  const candidates = [
    point?.meta?.probation,
    point?.probation,
    point?.meta?.centerMeta?.probation,
    point?.centerMeta?.probation,
    point?.payload?.candidateState?.probation,
    point?.payload?.candidateState?.centerMeta?.probation
  ];

  for (const candidate of candidates) {
    if (
      candidate &&
      typeof candidate === "object" &&
      !Array.isArray(candidate)
    ) {
      return candidate;
    }
  }

  return {};
}

function computeAverage(total, count) {
  const safeTotal = Number.isFinite(total) ? total : 0;
  const safeCount = Number.isFinite(count) ? count : 0;

  if (safeCount <= 0) {
    return 0;
  }

  return roundNumber(safeTotal / safeCount);
}

function computeDuplicateRate(params = {}) {
  const acceptedChildren = toSafeInteger(params.acceptedChildren);
  const duplicateChildren = toSafeInteger(params.duplicateChildren);
  const invalidChildren = toSafeInteger(params.invalidChildren);
  const otherRejectedChildren = toSafeInteger(params.otherRejectedChildren);

  const total =
    acceptedChildren +
    duplicateChildren +
    invalidChildren +
    otherRejectedChildren;

  if (total <= 0) {
    return 0;
  }

  return roundNumber(duplicateChildren / total);
}

function selectLowerNumber(currentValue, candidateValue) {
  if (!Number.isFinite(candidateValue)) {
    return Number.isFinite(currentValue) ? currentValue : null;
  }

  if (!Number.isFinite(currentValue)) {
    return candidateValue;
  }

  return candidateValue < currentValue
    ? candidateValue
    : currentValue;
}

function printCycleDetails(cycleSummary) {
  if (!Array.isArray(cycleSummary) || cycleSummary.length === 0) {
    console.log("none");
    return;
  }

  for (const cycle of cycleSummary) {
    const row = buildCompactCycleRow(cycle);

    if (!row) {
      continue;
    }

    console.log(
      `[CYCLE ${row.cycle}] points=${row.after} delta=${row.delta} accepted=${row.accepted} rejected=${row.rejected}`,
      {
        proposalClasses: row.proposalClasses,
        acceptedByClass: row.acceptedByClass,
        rejectedByClass: row.rejectedByClass
      }
    );
  }
}

function getMainRejectionReason(rejectionSummary) {
  const byReason =
    rejectionSummary &&
    typeof rejectionSummary === "object" &&
    !Array.isArray(rejectionSummary) &&
    rejectionSummary.byReason &&
    typeof rejectionSummary.byReason === "object" &&
    !Array.isArray(rejectionSummary.byReason)
      ? rejectionSummary.byReason
      : {};

  let bestReason = null;
  let bestCount = 0;

  for (const [reason, value] of Object.entries(byReason)) {
    const count = toSafeInteger(value);

    if (count > bestCount) {
      bestReason = reason;
      bestCount = count;
    }
  }

  return {
    reason: bestReason,
    count: bestCount
  };
}

function printLocalOpenQuality(params = {}) {
  const proposalClassSummary =
    params.proposalClassSummary &&
    typeof params.proposalClassSummary === "object" &&
    !Array.isArray(params.proposalClassSummary)
      ? params.proposalClassSummary
      : {};

  const totals =
    params.totals && typeof params.totals === "object" && !Array.isArray(params.totals)
      ? params.totals
      : {};

  const filtering =
    params.filtering &&
    typeof params.filtering === "object" &&
    !Array.isArray(params.filtering)
      ? params.filtering
      : {};

  const perSourceCenter =
    params.perSourceCenter &&
    typeof params.perSourceCenter === "object" &&
    !Array.isArray(params.perSourceCenter)
      ? params.perSourceCenter
      : {};

  const localOpenClassStats =
    proposalClassSummary.local_open &&
    typeof proposalClassSummary.local_open === "object" &&
    !Array.isArray(proposalClassSummary.local_open)
      ? proposalClassSummary.local_open
      : {};

  const distribution = buildLocalOpenDistribution(perSourceCenter);
  const topSources = buildTopLocalOpenSources(perSourceCenter);
  const crossCheck = buildLocalOpenCrossCheck({
    proposalClassStats: localOpenClassStats,
    totals,
    perSourceCenter
  });

  printSummarySection("totals:", {
    generatedRawCount: toSafeInteger(totals.rawCount),
    justifiedCount: toSafeInteger(totals.justifiedCount),
    locallyKeptCount: toSafeInteger(totals.keptCount),
    realizedCount: toSafeInteger(totals.realizedCount),
    acceptedCount: toSafeInteger(totals.acceptedCount),
    rejectedCount: toSafeInteger(totals.rejectedCount),
    droppedAfterKeepCount:
      Math.max(0, toSafeInteger(totals.keptCount) - toSafeInteger(totals.realizedCount))
  });

  printSummarySection("filtering:", {
    filteredNonComparable: toSafeInteger(filtering.filteredNonComparable),
    filteredNearZeroDistance: toSafeInteger(filtering.filteredNearZeroDistance),
    filteredNearZeroRelativeNovelty: toSafeInteger(
      filtering.filteredNearZeroRelativeNovelty
    ),
    bootstrapBypassCount: toSafeInteger(filtering.bootstrapBypassCount),
    bootstrapSelectedCount: toSafeInteger(filtering.bootstrapSelectedCount)
  });

  printSummarySection("distribution:", distribution);
  printSummarySection("topSources:", topSources);
  printSummarySection("crossCheck:", crossCheck);
}

function buildLocalOpenDistribution(perSourceCenter) {
  const entries = Object.entries(perSourceCenter);
  const sourceCount = entries.length;

  if (sourceCount === 0) {
    return {
      sourceCentersSeen: 0,
      sourceCentersWithAccepted: 0,
      avgRawPerSource: 0,
      avgJustifiedPerSource: 0,
      avgKeptPerSource: 0,
      avgAcceptedPerSource: 0,
      maxAcceptedFromSingleSource: 0
    };
  }

  let rawTotal = 0;
  let justifiedTotal = 0;
  let keptTotal = 0;
  let acceptedTotal = 0;
  let sourceCentersWithAccepted = 0;
  let maxAcceptedFromSingleSource = 0;

  for (const [, stats] of entries) {
    const rawCount = toSafeInteger(stats?.rawCount);
    const justifiedCount = toSafeInteger(stats?.justifiedCount);
    const keptCount = toSafeInteger(stats?.keptCount);
    const acceptedCount = toSafeInteger(stats?.acceptedCount);

    rawTotal += rawCount;
    justifiedTotal += justifiedCount;
    keptTotal += keptCount;
    acceptedTotal += acceptedCount;

    if (acceptedCount > 0) {
      sourceCentersWithAccepted += 1;
    }

    if (acceptedCount > maxAcceptedFromSingleSource) {
      maxAcceptedFromSingleSource = acceptedCount;
    }
  }

  return {
    sourceCentersSeen: sourceCount,
    sourceCentersWithAccepted,
    avgRawPerSource: roundNumber(rawTotal / sourceCount),
    avgJustifiedPerSource: roundNumber(justifiedTotal / sourceCount),
    avgKeptPerSource: roundNumber(keptTotal / sourceCount),
    avgAcceptedPerSource: roundNumber(acceptedTotal / sourceCount),
    maxAcceptedFromSingleSource
  };
}

function buildTopLocalOpenSources(perSourceCenter) {
  return Object.entries(perSourceCenter)
    .map(([sourcePointId, stats]) => ({
      sourcePointId,
      rawCount: toSafeInteger(stats?.rawCount),
      justifiedCount: toSafeInteger(stats?.justifiedCount),
      keptCount: toSafeInteger(stats?.keptCount),
      realizedCount: toSafeInteger(stats?.realizedCount),
      acceptedCount: toSafeInteger(stats?.acceptedCount),
      rejectedCount: toSafeInteger(stats?.rejectedCount)
    }))
    .sort(compareTopSourceRows)
    .slice(0, 10);
}

function buildLocalOpenCrossCheck(params = {}) {
  const proposalClassStats =
    params.proposalClassStats &&
    typeof params.proposalClassStats === "object" &&
    !Array.isArray(params.proposalClassStats)
      ? params.proposalClassStats
      : {};

  const totals =
    params.totals && typeof params.totals === "object" && !Array.isArray(params.totals)
      ? params.totals
      : {};

  const perSourceCenter =
    params.perSourceCenter &&
    typeof params.perSourceCenter === "object" &&
    !Array.isArray(params.perSourceCenter)
      ? params.perSourceCenter
      : {};

  const perSourceSums = {
    rawCount: 0,
    justifiedCount: 0,
    keptCount: 0,
    realizedCount: 0,
    acceptedCount: 0,
    rejectedCount: 0
  };

  for (const stats of Object.values(perSourceCenter)) {
    perSourceSums.rawCount += toSafeInteger(stats?.rawCount);
    perSourceSums.justifiedCount += toSafeInteger(stats?.justifiedCount);
    perSourceSums.keptCount += toSafeInteger(stats?.keptCount);
    perSourceSums.realizedCount += toSafeInteger(stats?.realizedCount);
    perSourceSums.acceptedCount += toSafeInteger(stats?.acceptedCount);
    perSourceSums.rejectedCount += toSafeInteger(stats?.rejectedCount);
  }

  const totalsSafe = {
    rawCount: toSafeInteger(totals.rawCount),
    justifiedCount: toSafeInteger(totals.justifiedCount),
    keptCount: toSafeInteger(totals.keptCount),
    realizedCount: toSafeInteger(totals.realizedCount),
    acceptedCount: toSafeInteger(totals.acceptedCount),
    rejectedCount: toSafeInteger(totals.rejectedCount)
  };

  const proposalClassSafe = {
    submittedCount: toSafeInteger(proposalClassStats.rawCount),
    realizedCount: toSafeInteger(proposalClassStats.realizedCount),
    acceptedCount: toSafeInteger(proposalClassStats.acceptedCount),
    rejectedCount: toSafeInteger(proposalClassStats.rejectedCount)
  };

  const warnings = [];

  if (perSourceSums.rawCount !== totalsSafe.rawCount) {
    warnings.push("perSource.rawCount != totals.generatedRawCount");
  }

  if (perSourceSums.justifiedCount !== totalsSafe.justifiedCount) {
    warnings.push("perSource.justifiedCount != totals.justifiedCount");
  }

  if (perSourceSums.keptCount !== totalsSafe.keptCount) {
    warnings.push("perSource.keptCount != totals.locallyKeptCount");
  }

  if (perSourceSums.realizedCount !== totalsSafe.realizedCount) {
    warnings.push("perSource.realizedCount != totals.realizedCount");
  }

  if (perSourceSums.acceptedCount !== totalsSafe.acceptedCount) {
    warnings.push("perSource.acceptedCount != totals.acceptedCount");
  }

  if (perSourceSums.rejectedCount !== totalsSafe.rejectedCount) {
    warnings.push("perSource.rejectedCount != totals.rejectedCount");
  }

  if (proposalClassSafe.realizedCount !== totalsSafe.realizedCount) {
    warnings.push("proposalClass.local_open.realizedCount != localOpenQuality.realizedCount");
  }

  if (proposalClassSafe.acceptedCount !== totalsSafe.acceptedCount) {
    warnings.push("proposalClass.local_open.acceptedCount != localOpenQuality.acceptedCount");
  }

  if (proposalClassSafe.rejectedCount !== totalsSafe.rejectedCount) {
    warnings.push("proposalClass.local_open.rejectedCount != localOpenQuality.rejectedCount");
  }

  return {
    proposalClassLocalOpen: proposalClassSafe,
    totals: {
      generatedRawCount: totalsSafe.rawCount,
      justifiedCount: totalsSafe.justifiedCount,
      locallyKeptCount: totalsSafe.keptCount,
      realizedCount: totalsSafe.realizedCount,
      acceptedCount: totalsSafe.acceptedCount,
      rejectedCount: totalsSafe.rejectedCount
    },
    perSourceSums,
    ok: warnings.length === 0,
    warnings
  };
}

function cloneNumberMap(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }

  const out = {};

  for (const [key, entry] of Object.entries(value)) {
    out[key] = toSafeInteger(entry);
  }

  return out;
}

function cloneNestedCenterAdmissionMap(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }

  const out = {};

  for (const [openingType, entry] of Object.entries(value)) {
    out[openingType] = {
      submitted: toSafeInteger(entry?.submitted),
      admitted: toSafeInteger(entry?.admitted),
      rejected: toSafeInteger(entry?.rejected)
    };
  }

  return out;
}

function clonePlainObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }

  try {
    return JSON.parse(JSON.stringify(value));
  } catch (_error) {
    return {};
  }
}

function compareProposalClassKeys(a, b) {
  const rankA = proposalClassRank(a);
  const rankB = proposalClassRank(b);

  if (rankA !== rankB) {
    return rankA - rankB;
  }

  return String(a).localeCompare(String(b));
}

function proposalClassRank(value) {
  switch (value) {
    case "deepjump_open":
      return 0;
    case "deep_jump_open":
      return 0;
    case "jump_open":
      return 1;
    case "local_open":
      return 2;
    default:
      return 100;
  }
}

function compareTopSourceRows(a, b) {
  if (b.acceptedCount !== a.acceptedCount) {
    return b.acceptedCount - a.acceptedCount;
  }

  if (b.realizedCount !== a.realizedCount) {
    return b.realizedCount - a.realizedCount;
  }

  if (b.keptCount !== a.keptCount) {
    return b.keptCount - a.keptCount;
  }

  if (b.justifiedCount !== a.justifiedCount) {
    return b.justifiedCount - a.justifiedCount;
  }

  if (b.rawCount !== a.rawCount) {
    return b.rawCount - a.rawCount;
  }

  return String(a.sourcePointId).localeCompare(String(b.sourcePointId));
}


function normalizeNegativeZero(value) {
  return Object.is(value, -0) ? 0 : value;
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.length > 0) {
      return value;
    }
  }

  return null;
}

function toSafeInteger(value) {
  if (!Number.isFinite(value)) {
    return 0;
  }

  const normalized = Math.trunc(value);
  return normalized >= 0 ? normalized : 0;
}

function toSafeIntegerOrNull(value) {
  return Number.isFinite(value) ? Math.trunc(value) : null;
}

function toSafeNumberOrNull(value) {
  return Number.isFinite(value) ? Number(value) : null;
}

function toBooleanOrNull(value) {
  if (typeof value === "boolean") {
    return value;
  }

  return null;
}

function roundNumber(value) {
  if (!Number.isFinite(value)) {
    return 0;
  }

  return Math.round(value * 1000000) / 1000000;
}


function buildBestHP2DFoldArtifact(params = {}) {
  const { runStats, bestResult, problemMeta, compactBest } = params;

  if (!bestResult || typeof bestResult !== "object") {
    return null;
  }

  const expectedLength = firstFiniteInteger([
    problemMeta?.sequenceLength,
    bestResult?.resultView?.sequenceLength,
    compactBest?.sequenceLength
  ]);

  const sequence = findHP2DSequence({
    values: [
      problemMeta,
      bestResult,
      runStats?.problem,
      runStats?.problemMeta,
      runStats?.bestResult
    ],
    expectedLength
  });

  const pathSearch = findHP2DPath({
    value: bestResult,
    expectedLength: Number.isInteger(expectedLength) ? expectedLength : sequence?.length || null
  }) || findHP2DPath({
    value: runStats,
    expectedLength: Number.isInteger(expectedLength) ? expectedLength : sequence?.length || null,
    preferredCandidateId: bestResult?.provenance?.candidateId || null
  });

  if (!pathSearch || !Array.isArray(pathSearch.path)) {
    if (!EXPORT_HP2D_FOLD_ARTIFACT) {
      return null;
    }

    return {
      exportStatus: "missing_path_in_run_summary_payload",
      explanation: "No HP2D coordinate path was found inside runStats.bestResult/resultView/display or nearby runStats fields. Patch the result-view/bestResult builder to include candidate.path.",
      candidateId: bestResult?.provenance?.candidateId || null,
      sequence: sequence || null,
      expectedLength: Number.isInteger(expectedLength) ? expectedLength : null,
      searchedRoots: ["runStats.bestResult", "runStats"]
    };
  }

  const rawPath = pathSearch.path.map(cloneArtifactPoint);
  const normalizedPath = normalizeArtifactPathOrigin(rawPath);
  const artifactSequence = sequence || findHP2DSequence({ values: [bestResult, runStats], expectedLength: normalizedPath.length });

  if (!artifactSequence || artifactSequence.length !== normalizedPath.length) {
    return {
      exportStatus: "missing_or_mismatched_sequence",
      explanation: "A coordinate path was found, but no matching HP sequence was available in runStats/problemMeta/bestResult.",
      candidateId: bestResult?.provenance?.candidateId || null,
      pathSource: pathSearch.source,
      coordsLength: normalizedPath.length,
      sequence: artifactSequence || null,
      expectedLength: Number.isInteger(expectedLength) ? expectedLength : null
    };
  }

  const validation = validateHP2DArtifactPath(normalizedPath);
  const contacts = validation.valid
    ? computeHHArtifactContacts({ sequence: artifactSequence, path: normalizedPath })
    : [];
  const validatedEnergy = validation.valid ? normalizeNegativeZero(-contacts.length) : null;
  const coords = normalizedPath.map((point, index) => ({
    index,
    residue: artifactSequence[index],
    x: point.x,
    y: point.y
  }));
  const compactPath = coords.map((point) => `${point.index}${point.residue}@${point.x},${point.y}`).join(";");
  const canonical = JSON.stringify({
    benchmarkId: problemMeta?.benchmarkId || null,
    sequence: artifactSequence,
    coords
  });
  const sha256 = sha256Hex(canonical);

  return {
    exportStatus: validation.valid ? "ok" : "invalid_path",
    artifactType: "hp2d_best_fold",
    benchmarkId: problemMeta?.benchmarkId || null,
    problemId: problemMeta?.problemId || null,
    sequence: artifactSequence,
    sequenceLength: artifactSequence.length,
    candidateId: bestResult?.provenance?.candidateId || null,
    candidateStatus: bestResult?.provenance?.candidateStatus || null,
    proposalClass: bestResult?.provenance?.proposalClass || null,
    openingType: bestResult?.provenance?.openingType || null,
    sourcePointId: bestResult?.provenance?.sourcePointId || null,
    sourceType: bestResult?.provenance?.sourceType || null,
    strongestScaleType: bestResult?.provenance?.strongestScaleType || null,
    primitiveScaleType: bestResult?.provenance?.primitiveScaleType || null,
    improvedAtCycle: toSafeIntegerOrNull(bestResult?.improvedAtCycle),
    improvedAtPointCount: toSafeIntegerOrNull(bestResult?.improvedAtPointCount),
    reportedEnergy: toSafeNumberOrNull(bestResult?.comparison?.primaryValue ?? compactBest?.energy),
    reportedContacts: toSafeNumberOrNull(bestResult?.comparison?.secondaryValue ?? compactBest?.secondaryValue),
    validatedEnergy,
    validatedContacts: contacts.length,
    valid: validation.valid,
    violations: validation.violations,
    coordsLength: coords.length,
    coords,
    hhContacts: contacts,
    boundingBox: computeArtifactBoundingBox(normalizedPath),
    pathSource: pathSearch.source,
    originNormalized: true,
    pathKey: normalizedPath.map((point) => `${point.x}:${point.y}`).join("|"),
    compactPath,
    sha256
  };
}

function writeBestHP2DFoldArtifact(artifact) {
  if (!artifact || typeof artifact !== "object") {
    return;
  }

  const dir = HP2D_FOLD_ARTIFACT_DIR || pathModule.join(process.cwd(), "logs", "fold-artifacts");

  try {
    fs.mkdirSync(dir, { recursive: true });
    const energyLabel = Number.isFinite(artifact.validatedEnergy)
      ? String(artifact.validatedEnergy).replace(/-/g, "minus-")
      : "unknown-energy";
    const candidateLabel = artifact.candidateId || `candidate-${Date.now()}`;
    const basename = `hp2d-${artifact.benchmarkId || "benchmark"}-${energyLabel}-${candidateLabel}`.replace(/[^a-zA-Z0-9_.-]/g, "_");
    const jsonPath = pathModule.join(dir, `${basename}.json`);
    const svgPath = pathModule.join(dir, `${basename}.svg`);

    fs.writeFileSync(jsonPath, `${JSON.stringify(artifact, null, 2)}\n`, "utf8");

    if (artifact.valid === true && Array.isArray(artifact.coords)) {
      fs.writeFileSync(svgPath, buildHP2DFoldSvg(artifact), "utf8");
    }

    printSummarySection("BEST HP2D FOLD ARTIFACT FILES", {
      jsonPath,
      svgPath: artifact.valid === true && Array.isArray(artifact.coords) ? svgPath : null,
      sha256: artifact.sha256 || null
    });
  } catch (error) {
    printSummarySection("BEST HP2D FOLD ARTIFACT WRITE ERROR", {
      message: error?.message || String(error),
      dir
    });
  }
}

function findHP2DPath(params = {}) {
  const { value, expectedLength = null, preferredCandidateId = null } = params;
  const visited = new WeakSet();
  const queue = [{ value, source: "root", score: 0 }];
  let best = null;

  while (queue.length > 0) {
    const entry = queue.shift();
    const current = entry.value;

    if (!current || typeof current !== "object") {
      continue;
    }

    if (visited.has(current)) {
      continue;
    }

    visited.add(current);

    if (Array.isArray(current) && isArtifactPointPath(current, expectedLength)) {
      const candidate = { path: current, source: entry.source, score: entry.score + scoreArtifactPathSource(entry.source) };
      if (!best || candidate.score > best.score) {
        best = candidate;
      }
      continue;
    }

    const objectCandidateId = firstString(
      current?.id,
      current?.candidateId,
      current?.pointId,
      current?.meta?.candidateId,
      current?.payload?.candidateId,
      current?.payload?.candidateState?.candidateId
    );
    const idBonus = preferredCandidateId && objectCandidateId === preferredCandidateId ? 1000 : 0;

    for (const key of preferredArtifactPathKeys()) {
      const child = current[key];
      if (Array.isArray(child) && isArtifactPointPath(child, expectedLength)) {
        const source = `${entry.source}.${key}`;
        const candidate = { path: child, source, score: entry.score + idBonus + scoreArtifactPathSource(source) };
        if (!best || candidate.score > best.score) {
          best = candidate;
        }
      }
    }

    for (const [key, child] of Object.entries(current)) {
      if (!child || typeof child !== "object") {
        continue;
      }
      queue.push({
        value: child,
        source: `${entry.source}.${key}`,
        score: entry.score + idBonus
      });
    }
  }

  return best;
}

function preferredArtifactPathKeys() {
  return [
    "path",
    "coords",
    "coordinates",
    "points",
    "latticePath",
    "foldPath"
  ];
}

function scoreArtifactPathSource(source) {
  const text = String(source || "");
  let score = 0;

  if (/bestResult/u.test(text)) score += 80;
  if (/resultView/u.test(text)) score += 60;
  if (/problemCandidate|candidateState|candidate/u.test(text)) score += 40;
  if (/display/u.test(text)) score += 30;
  if (/path/u.test(text)) score += 20;
  if (/coords|coordinates/u.test(text)) score += 10;

  return score;
}

function isArtifactPointPath(value, expectedLength = null) {
  if (!Array.isArray(value) || value.length === 0) {
    return false;
  }

  if (Number.isInteger(expectedLength) && expectedLength > 0 && value.length !== expectedLength) {
    return false;
  }

  return value.every((point) =>
    point &&
    typeof point === "object" &&
    !Array.isArray(point) &&
    Number.isFinite(point.x) &&
    Number.isFinite(point.y)
  );
}

function findHP2DSequence(params = {}) {
  const { values = [], expectedLength = null } = params;

  for (const value of values) {
    const found = findHP2DSequenceInValue(value, expectedLength, new WeakSet());
    if (found) {
      return found;
    }
  }

  return null;
}

function findHP2DSequenceInValue(value, expectedLength, visited) {
  if (typeof value === "string") {
    const normalized = value.trim().toUpperCase();
    if (/^[HP]+$/u.test(normalized) && (!Number.isInteger(expectedLength) || normalized.length === expectedLength)) {
      return normalized;
    }
    return null;
  }

  if (!value || typeof value !== "object") {
    return null;
  }

  if (visited.has(value)) {
    return null;
  }

  visited.add(value);

  const preferred = [
    value.sequence,
    value.hpSequence,
    value.problemSequence,
    value?.problem?.sequence,
    value?.problemMeta?.sequence,
    value?.resultView?.sequence,
    value?.candidate?.sequence,
    value?.problemCandidate?.sequence,
    value?.candidateState?.sequence,
    value?.payload?.sequence,
    value?.payload?.candidateState?.sequence
  ];

  for (const candidate of preferred) {
    const found = findHP2DSequenceInValue(candidate, expectedLength, visited);
    if (found) {
      return found;
    }
  }

  for (const child of Object.values(value)) {
    const found = findHP2DSequenceInValue(child, expectedLength, visited);
    if (found) {
      return found;
    }
  }

  return null;
}

function firstFiniteInteger(values) {
  if (!Array.isArray(values)) {
    return null;
  }

  for (const value of values) {
    if (Number.isFinite(value)) {
      return Math.trunc(value);
    }
  }

  return null;
}

function cloneArtifactPoint(point) {
  return { x: Number(point.x), y: Number(point.y) };
}

function normalizeArtifactPathOrigin(path) {
  const box = computeArtifactBoundingBox(path);
  return path.map((point) => ({
    x: point.x - box.minX,
    y: point.y - box.minY
  }));
}

function computeArtifactBoundingBox(path) {
  if (!Array.isArray(path) || path.length === 0) {
    return { minX: 0, maxX: 0, minY: 0, maxY: 0, width: 0, height: 0, area: 0 };
  }

  let minX = Number.POSITIVE_INFINITY;
  let maxX = Number.NEGATIVE_INFINITY;
  let minY = Number.POSITIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;

  for (const point of path) {
    minX = Math.min(minX, point.x);
    maxX = Math.max(maxX, point.x);
    minY = Math.min(minY, point.y);
    maxY = Math.max(maxY, point.y);
  }

  const width = maxX - minX + 1;
  const height = maxY - minY + 1;

  return { minX, maxX, minY, maxY, width, height, area: width * height };
}

function validateHP2DArtifactPath(path) {
  const violations = [];

  if (!Array.isArray(path) || path.length === 0) {
    return { valid: false, violations: ["path_missing_or_empty"] };
  }

  const occupied = new Set();

  for (let i = 0; i < path.length; i += 1) {
    const point = path[i];

    if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y)) {
      violations.push(`invalid_point_at_${i}`);
      continue;
    }

    const key = `${point.x}:${point.y}`;
    if (occupied.has(key)) {
      violations.push(`self_overlap_at_${i}_${key}`);
    }
    occupied.add(key);

    if (i > 0 && artifactManhattanDistance(path[i - 1], point) !== 1) {
      violations.push(`broken_chain_between_${i - 1}_${i}`);
    }
  }

  return { valid: violations.length === 0, violations };
}

function computeHHArtifactContacts(params = {}) {
  const { sequence, path } = params;
  const contacts = [];

  if (typeof sequence !== "string" || !Array.isArray(path) || sequence.length !== path.length) {
    return contacts;
  }

  for (let i = 0; i < path.length; i += 1) {
    if (sequence[i] !== "H") {
      continue;
    }

    for (let j = i + 2; j < path.length; j += 1) {
      if (sequence[j] !== "H") {
        continue;
      }

      if (Math.abs(i - j) === 1) {
        continue;
      }

      if (artifactManhattanDistance(path[i], path[j]) === 1) {
        contacts.push({
          i,
          j,
          xi: path[i].x,
          yi: path[i].y,
          xj: path[j].x,
          yj: path[j].y
        });
      }
    }
  }

  return contacts;
}

function artifactManhattanDistance(a, b) {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
}

function sha256Hex(value) {
  return crypto.createHash("sha256").update(String(value)).digest("hex");
}

function buildHP2DFoldSvg(artifact) {
  const coords = Array.isArray(artifact.coords) ? artifact.coords : [];
  const contacts = Array.isArray(artifact.hhContacts) ? artifact.hhContacts : [];
  const box = artifact.boundingBox || { width: 1, height: 1 };
  const cell = 42;
  const margin = 42;
  const width = Math.max(1, box.width) * cell + margin * 2;
  const height = Math.max(1, box.height) * cell + margin * 2;

  function sx(x) { return margin + x * cell; }
  function sy(y) { return margin + y * cell; }
  function esc(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;");
  }

  const byIndex = new Map(coords.map((point) => [point.index, point]));
  const parts = [];

  parts.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`);
  parts.push(`<rect width="100%" height="100%" fill="white"/>`);
  parts.push(`<text x="${margin}" y="22" font-family="Arial, sans-serif" font-size="14" fill="#111">${esc(artifact.benchmarkId || "HP2D")} | energy ${esc(artifact.validatedEnergy)} | contacts ${esc(artifact.validatedContacts)} | ${esc(artifact.candidateId || "")}</text>`);

  for (const contact of contacts) {
    const a = byIndex.get(contact.i);
    const b = byIndex.get(contact.j);
    if (!a || !b) continue;
    parts.push(`<line x1="${sx(a.x)}" y1="${sy(a.y)}" x2="${sx(b.x)}" y2="${sy(b.y)}" stroke="#2f6fed" stroke-width="3" stroke-dasharray="6 6" opacity="0.7"/>`);
  }

  for (let i = 1; i < coords.length; i += 1) {
    const a = coords[i - 1];
    const b = coords[i];
    parts.push(`<line x1="${sx(a.x)}" y1="${sy(a.y)}" x2="${sx(b.x)}" y2="${sy(b.y)}" stroke="#222" stroke-width="4" stroke-linecap="round"/>`);
  }

  for (const point of coords) {
    const isH = point.residue === "H";
    const fill = isH ? "#111111" : "#ffffff";
    const stroke = isH ? "#111111" : "#666666";
    const textFill = isH ? "#ffffff" : "#111111";
    parts.push(`<circle cx="${sx(point.x)}" cy="${sy(point.y)}" r="15" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`);
    parts.push(`<text x="${sx(point.x)}" y="${sy(point.y) + 5}" text-anchor="middle" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="${textFill}">${esc(point.residue)}</text>`);
    parts.push(`<text x="${sx(point.x)}" y="${sy(point.y) - 20}" text-anchor="middle" font-family="Arial, sans-serif" font-size="8" fill="#555">${point.index}</text>`);
  }

  parts.push(`</svg>`);
  return `${parts.join("\n")}\n`;
}

module.exports = {
  printRunSummary
};