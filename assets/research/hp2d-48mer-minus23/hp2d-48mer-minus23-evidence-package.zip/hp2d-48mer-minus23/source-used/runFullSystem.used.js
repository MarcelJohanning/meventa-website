"use strict";

const {
  projectConflictSpace
} = require("../conflictSpace/projection/projectConflictSpace");
const {
  runExplorationCycle
} = require("../exploration/explorationCycle");

const {
  ProblemRealizationDriver
} = require("../realization/ProblemRealizationDriver");

const {
  createRealizeBatchAdapter
} = require("../realizer/realizeBatchAdapter");
const {
  createProblemRuntime
} = require("../../problem/problemSpace/problemRuntime");
const { printDensityStats } = require("../debug/densityStats");

const { loadProblem } = require("../../problem/loadProblem");
const {
  buildHP2DInitialConflictSpace
} = require("../../problem/hp2d/hp2dConflictBootstrap");
const {
  createHP2DProblemRealizer
} = require("../../problem/hp2d/hp2dProblemRealizer");

const {
  createRunStats,
  beginCycle,
  finishCycle,
  finishRun,
  updateBestResultFromPoints,
  updateCenterSummaryFromPoints,
  maybeBuildLiveBestCheckpoint
} = require("../tracing/runStats");

const {
  printRunSummary
} = require("../tracing/printRunSummary");

const DEBUG_SYSTEM = process.env.DEBUG_SYSTEM === "1";
const PRINT_DENSITY_STATS = process.env.PRINT_DENSITY_STATS === "1";
const PRINT_CYCLE_TARGETS = process.env.PRINT_CYCLE_TARGETS === "1";

const MAX_CYCLES = Number(process.env.MAX_CYCLES || 50);
const PROBLEM_ID = process.env.PROBLEM_ID || undefined;

function summarizeTargets(result) {
  if (!Array.isArray(result?.targets)) {
    return [];
  }

  return result.targets.map((target) => ({
    id: target?.point?.id || null,
    type: target?.structure?.type || null,
    score: Number((target?.score || 0).toFixed(3))
  }));
}

function logCycleSummary(params = {}) {
  const {
    cycleIndex,
    pointCountBefore,
    pointCountAfter,
    result
  } = params;

  const proposalCount = Array.isArray(result?.proposals)
    ? result.proposals.length
    : 0;

  const candidateCount = Array.isArray(result?.realization?.candidates)
    ? result.realization.candidates.length
    : 0;

  const experienceRecord =
    result?.trace?.experienceRecord &&
    typeof result.trace.experienceRecord === "object"
      ? result.trace.experienceRecord
      : {};

  const acceptedCount = Array.isArray(experienceRecord.acceptedCandidates)
    ? experienceRecord.acceptedCandidates.length
    : Number.isFinite(experienceRecord.acceptedCount)
      ? experienceRecord.acceptedCount
      : 0;

  const rejectedCount = Array.isArray(experienceRecord.rejectedCandidates)
    ? experienceRecord.rejectedCandidates.length
    : Number.isFinite(experienceRecord.rejectedCount)
      ? experienceRecord.rejectedCount
      : 0;

  const pointDelta = pointCountAfter - pointCountBefore;

  const row = {
    points: pointCountAfter,
    delta: pointDelta,
    proposals: proposalCount,
    candidates: candidateCount,
    accepted: acceptedCount,
    rejected: rejectedCount
  };

  if (PRINT_CYCLE_TARGETS) {
    row.targets = summarizeTargets(result);
  }

  console.log(`[CYCLE ${cycleIndex + 1}]`, row);
}

function logSystemDebug(result) {
  if (!DEBUG_SYSTEM) {
    return;
  }

  try {
    console.log("[SYSTEM]", {
      proposalCount: Array.isArray(result?.proposals)
        ? result.proposals.length
        : 0,
      candidateCount: Array.isArray(result?.realization?.candidates)
        ? result.realization.candidates.length
        : 0
    });
  } catch (error) {
    console.log("[SYSTEM ERROR]", error?.message || error);
  }
}

function buildProblemLog(problem) {
  return {
    id: problem?.id || null,
    type: problem?.type || null,
    benchmarkId: problem?.benchmarkId || null,
    sequenceLength: problem?.sequenceLength || 0,
    maxCycles: MAX_CYCLES
  };
}

function createProblemRuntimeCompat(problem, problemAdapter) {
  const problemRuntime = createProblemRuntime(problem);

  if (
    problemAdapter &&
    typeof problemAdapter === "object" &&
    !Array.isArray(problemAdapter)
  ) {
    problemRuntime.problemAdapter = problemAdapter;
  }

  if (!problemRuntime.problem) {
    problemRuntime.problem = problem;
  }

  problemRuntime.problemRealizer = createProblemRealizerForProblem(problem);

  return problemRuntime;
}

function createProblemRealizerForProblem(problem) {
  switch (problem?.type) {
    case "hp-folding-2d":
      return createHP2DProblemRealizer();
    default:
      throw new Error(
        `No problem realizer registered for problem type: ${
          problem?.type || "unknown"
        }`
      );
  }
}

async function buildInitialConflictSpace(problemRuntime, problem) {
  switch (problem?.type) {
    case "hp-folding-2d":
      return buildHP2DInitialConflictSpace(problemRuntime, problem);
    default:
      throw new Error(
        `No initial conflict space bootstrap registered for problem type: ${
          problem?.type || "unknown"
        }`
      );
  }
}

function buildRunStatsInit(problem, state, problemAdapter) {
  return {
    maxCyclesConfigured: MAX_CYCLES,
    problemId: problem?.id || null,
    problemType: problem?.type || null,
    benchmarkId: problem?.benchmarkId || null,
    sequenceLength: problem?.sequenceLength || 0,
    sequence: problem?.sequence || null,
    reference:
      problem?.reference && typeof problem.reference === "object"
        ? problem.reference
        : null,
    initialPointCount: Array.isArray(state?.points) ? state.points.length : 0,
    resultExtractor: createResultExtractor(problem, problemAdapter)
  };
}


function resolveHP2DSequence(problemCandidate, problem) {
  if (typeof problemCandidate?.sequence === "string" && problemCandidate.sequence.length > 0) {
    return problemCandidate.sequence;
  }

  if (Array.isArray(problemCandidate?.sequence)) {
    return problemCandidate.sequence.join("");
  }

  if (typeof problem?.sequence === "string" && problem.sequence.length > 0) {
    return problem.sequence;
  }

  return null;
}

function normalizeHP2DPathForDisplay(path) {
  if (!Array.isArray(path)) {
    return [];
  }

  const normalized = [];

  for (const point of path) {
    if (!point || typeof point !== "object" || Array.isArray(point)) {
      return [];
    }

    if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) {
      return [];
    }

    normalized.push({ x: point.x, y: point.y });
  }

  return normalized;
}

function buildHP2DDisplayCoords(params = {}) {
  const { sequence, path } = params;

  if (!Array.isArray(path) || path.length === 0) {
    return [];
  }

  return path.map((point, index) => ({
    index,
    residue: typeof sequence === "string" ? sequence[index] || null : null,
    x: point.x,
    y: point.y
  }));
}

function createResultExtractor(problem, problemAdapter) {
  if (problem?.type !== "hp-folding-2d") {
    return null;
  }

  if (!problemAdapter || typeof problemAdapter !== "object") {
    return null;
  }

  return async function extractHP2DResult(params = {}) {
    const problemCandidate = params.problemCandidate || null;

    if (!problemCandidate || typeof problemCandidate !== "object") {
      return null;
    }

    const validation =
      typeof problemAdapter.validateCandidate === "function"
        ? await problemAdapter.validateCandidate({
            problem,
            candidate: problemCandidate
          })
        : null;

    if (validation && validation.ok === false) {
      return null;
    }

    const metrics =
      typeof problemAdapter.computeCandidateMetrics === "function"
        ? await problemAdapter.computeCandidateMetrics({
            problem,
            candidate: problemCandidate
          })
        : null;

    const summary =
      typeof problemAdapter.summarizeCandidate === "function"
        ? await problemAdapter.summarizeCandidate({
            problem,
            candidate: problemCandidate
          })
        : null;

    const energy =
      Number.isFinite(metrics?.energy)
        ? metrics.energy
        : Number.isFinite(summary?.energy)
          ? summary.energy
          : Number.POSITIVE_INFINITY;

    const contacts =
      Number.isFinite(metrics?.hhContacts)
        ? metrics.hhContacts
        : Number.isFinite(metrics?.contacts)
          ? metrics.contacts
          : Number.isFinite(summary?.hhContacts)
            ? summary.hhContacts
            : Number.isFinite(summary?.contacts)
              ? summary.contacts
              : null;

    const sequence = resolveHP2DSequence(problemCandidate, problem);
    const path = normalizeHP2DPathForDisplay(problemCandidate.path);
    const coords = buildHP2DDisplayCoords({ sequence, path });

    return {
      resultView: {
        kind: "hp2d_result",
        candidateType: problemCandidate.kind || "hp2d_candidate",
        sequence,
        sequenceLength:
          typeof sequence === "string"
            ? sequence.length
            : problem?.sequenceLength || null,
        valid: true,
        metrics,
        summary,
        display: {
          energy,
          contacts,
          pathLength: path.length > 0 ? path.length : null,
          coords
        },
        hp2dFold: {
          sequence,
          path,
          coords,
          energy,
          contacts,
          valid: true,
          exportSource: "runFullSystem.resultExtractor.hp2dFoldArtifact.v1"
        },
        comparison: {
          objective: "minimize_energy",
          objectiveDirection: "minimize",
          primaryValue: energy,
          secondaryDirection: "maximize",
          secondaryValue: contacts
        }
      }
    };
  };
}

function logInterpretationDebug(result) {
  if (!DEBUG_SYSTEM) {
    return;
  }

  const realizedCandidates = Array.isArray(
    result?.trace?.experienceRecord?.realizedCandidates
  )
    ? result.trace.experienceRecord.realizedCandidates
    : [];

  console.log(
    "[DEBUG realizedCandidate sample]",
    JSON.stringify(realizedCandidates[0] || null, null, 2)
  );

  console.log("[DEBUG realizedCandidates count]", realizedCandidates.length);
}

function buildCycleContext(params = {}) {
  const {
    cycleIndex,
    problem,
    problemAdapter,
    problemRealizer,
    runStats
  } = params;

  return {
    cycleIndex,
    problemType: problem?.type || null,
    problemInstanceRef: problem?.id || null,
    problem,
    problemAdapter,
    problemRealizer,
    runStats
  };
}

function printLiveBestCheckpointAfterCycle(params = {}) {
  const {
    runStats,
    cycleNumber,
    pointCount
  } = params;

  if (!runStats || typeof runStats !== "object") {
    return;
  }

  const checkpoint = maybeBuildLiveBestCheckpoint(runStats, {
    cycle: cycleNumber,
    pointCount
  });

  if (checkpoint) {
    console.log("[LIVE HP2D BEST]", checkpoint);
  }
}

function createIncrementalBestPointExtractor() {
  let checkedPointCount = 0;

  return async function updateBestFromNewPoints(params = {}) {
    const {
      runStats,
      state,
      cycleNumber,
      pointCount
    } = params;

    if (!runStats || typeof runStats !== "object") {
      return;
    }

    const points = Array.isArray(state?.points)
      ? state.points
      : [];

    if (points.length === 0) {
      return;
    }

    const startIndex = Math.min(checkedPointCount, points.length);
    const newPoints = points.slice(startIndex);

    checkedPointCount = points.length;

    if (newPoints.length === 0) {
      return;
    }

    await updateBestResultFromPoints(runStats, newPoints, {
      cycleIndex: cycleNumber,
      pointCountAfter: pointCount
    });
  };
}

async function runSystem() {
  console.log("=== SYSTEM START ===");

  const { problem, problemAdapter } = loadProblem({
    problemId: PROBLEM_ID
  });

  if (DEBUG_SYSTEM) {
    console.log("[LOAD PROBLEM RESULT]", {
      problemKeys: problem ? Object.keys(problem) : null,
      problemId: problem?.id || null,
      adapterKeys: problemAdapter ? Object.keys(problemAdapter) : null
    });
  }

  const realizer = new ProblemRealizationDriver();
  const problemRuntime = createProblemRuntimeCompat(problem, problemAdapter);

  const rawConflictSpace = await buildInitialConflictSpace(
    problemRuntime,
    problem
  );

  const realizeBatch = await createRealizeBatchAdapter(
    realizer,
    problemRuntime
  );

  let state = projectConflictSpace(rawConflictSpace);

  console.log("PROBLEM", buildProblemLog(problem));
  console.log("INITIAL", {
    points: Array.isArray(state?.points) ? state.points.length : 0
  });

  const runStats = createRunStats(
    buildRunStatsInit(problem, state, problemAdapter)
  );

  const updateBestFromNewPoints = createIncrementalBestPointExtractor();

  let terminatedBy = "max_cycles";

  for (let i = 0; i < MAX_CYCLES; i += 1) {
    const pointCountBefore = Array.isArray(state?.points)
      ? state.points.length
      : 0;

    const cycleStats = beginCycle(runStats, {
      cycleIndex: i,
      pointCountBefore
    });

    const cycleContext = buildCycleContext({
      cycleIndex: i,
      problem,
      problemAdapter,
      problemRealizer: problemRuntime.problemRealizer,
      runStats
    });

    const result = await runExplorationCycle({
      conflictSpaceState: state,
      realizeBatch,
      options: {
        runStats,
        targetOptions: { maxTargets: 10 },
        proposalOptions: { maxProposals: 20 },
        cycleContext
      }
    });

    if (!result) {
      terminatedBy = "no_result";
      console.log(`[CYCLE ${i + 1}] no_result`);
      break;
    }

    state = result.nextConflictSpaceState;

    const pointCountAfter = Array.isArray(state?.points)
      ? state.points.length
      : pointCountBefore;

    logInterpretationDebug(result);

    finishCycle(runStats, cycleStats, {
      pointCountAfter,
      targets: summarizeTargets(result),
      experienceRecord: result?.trace?.experienceRecord || null
    });

  await updateBestFromNewPoints({
  runStats,
  state,
  cycleNumber: i + 1,
  pointCount: pointCountAfter
});

printLiveBestCheckpointAfterCycle({
  runStats,
  cycleNumber: i + 1,
  pointCount: pointCountAfter
});

    logSystemDebug(result);

    logCycleSummary({
      cycleIndex: i,
      pointCountBefore,
      pointCountAfter,
      result
    });
  }

  updateCenterSummaryFromPoints(runStats, state.points);

  finishRun(runStats, {
    terminatedBy,
    finalState: state
  });

  await updateBestResultFromPoints(runStats, state.points);

  updateCenterSummaryFromPoints(runStats, state.points);

  console.log("=== SYSTEM END ===");

  if (PRINT_DENSITY_STATS) {
    printDensityStats();
  }

  printRunSummary(runStats);
}

runSystem().catch((error) => {
  console.error(error);
  process.exit(1);
});