"use strict";

/**
 * hp2dProblemRealizer.js
 *
 * HP2D-specific ProblemRealizer.
 *
 * Responsibility:
 * - Convert sourceCandidate + RealizationIntent into real local HP2D candidates.
 * - Use local HP2D lattice moves only.
 * - Keep Runtime/Intent influence limited to ordering and small family selection.
 * - Return valid, evaluated HP2D problem candidates.
 *
 * Boundary:
 * - no embedding
 * - no matching
 * - no runtime point creation
 * - no Jump / DeepJump
 * - no global HP2D solver strategy
 */

const DEBUG_HP2D_REALIZER = process.env.DEBUG_HP2D_REALIZER === "1";
const DEBUG_REALIZATION_PLATEAU =
  process.env.DEBUG_REALIZATION_PLATEAU === "1";

const MAX_VARIANTS_PER_REALIZATION = readPositiveIntegerEnv(
  "HP2D_MAX_VARIANTS_PER_REALIZATION",
  24
);

const OPERATOR_FAMILIES = Object.freeze([
  "pivot_rotation",
  "prefix_pivot_rotation",
  "corner_flip",
  "crankshaft_move",
  "end_rotation",
  "pull_move_light",
  "contact_seeking_pivot",
  "contact_preserving_pivot"
]);

function createHP2DProblemRealizer() {
  return {
    realize
  };
}

async function realize(params = {}) {
  const { intent, sourceCandidate, problemContext = {} } = params;

  validateInputs(intent, sourceCandidate);

  const problem = problemContext?.problem || null;
  const baseCandidate = normalizeCandidate(sourceCandidate, problem);
  const candidates = generateVariants(baseCandidate, intent);

  if (DEBUG_HP2D_REALIZER || DEBUG_REALIZATION_PLATEAU) {
    logHP2DRealizerQuality({
      intent,
      baseCandidate,
      candidates
    });
  }

  return {
    candidates
  };
}

function generateVariants(candidate, intent) {
  const sourceMetrics = computeHP2DPathMetrics({
    sequence: candidate.sequence,
    path: candidate.path
  });

  if (sourceMetrics.valid !== true) {
    return [cloneCandidate(candidate)];
  }

  const operatorFamilies = selectOperatorFamiliesForIntent(intent);
  const rawVariants = [];

  for (const family of operatorFamilies) {
    switch (family) {
      case "pivot_rotation":
        rawVariants.push(...generatePivotVariants(candidate, intent));
        break;

      case "prefix_pivot_rotation":
        rawVariants.push(...generatePrefixPivotVariants(candidate, intent));
        break;

      case "corner_flip":
        rawVariants.push(...generateCornerFlipVariants(candidate, intent));
        break;

      case "crankshaft_move":
        rawVariants.push(...generateCrankshaftVariants(candidate, intent));
        break;

      case "end_rotation":
        rawVariants.push(...generateEndRotationVariants(candidate, intent));
        break;

      case "pull_move_light":
        rawVariants.push(...generatePullMoveLightVariants(candidate, intent));
        break;

      case "contact_seeking_pivot":
        rawVariants.push(
          ...generateContactSeekingPivotVariants(candidate, intent, sourceMetrics)
        );
        break;

      case "contact_preserving_pivot":
        rawVariants.push(
          ...generateContactPreservingPivotVariants(candidate, intent, sourceMetrics)
        );
        break;

      default:
        break;
    }
  }

  const validDeduped = dedupeCandidates(rawVariants).filter(
    (variant) => variant?.valid === true
  );

  if (validDeduped.length === 0) {
    return [
      attachRealizationDebug(cloneCandidate(candidate), {
        operatorFamilies,
        rawVariantCount: rawVariants.length,
        dedupedVariantCount: 0,
        cappedVariantCount: 1,
        sourcePathKey: shortPathKey(candidate.path),
        sourceEnergy: sourceMetrics.energy,
        sourceContacts: sourceMetrics.hhContacts,
        fallbackToSource: true
      })
    ];
  }

  const rows = rankCandidateRows({
    sourceCandidate: candidate,
    candidates: validDeduped
  });

  const selectedRows = rows.slice(0, MAX_VARIANTS_PER_REALIZATION);

  return selectedRows.map((row) =>
    attachRealizationDebug(row.candidate, {
      operatorFamilies,
      rawVariantCount: rawVariants.length,
      dedupedVariantCount: validDeduped.length,
      cappedVariantCount: selectedRows.length,
      sourcePathKey: shortPathKey(candidate.path),
      sourceEnergy: sourceMetrics.energy,
      sourceContacts: sourceMetrics.hhContacts,
      fallbackToSource: false
    })
  );
}

/**
 * Intent coupling stays intentionally small:
 * - one generic pivot foundation
 * - three rotated local move families
 * - no sourceEnergy/sourceContacts phase logic
 */
function selectOperatorFamiliesForIntent(intent) {
  const seed = computeIntentSeed(intent);
  const offset =
    OPERATOR_FAMILIES.length > 0 ? seed % OPERATOR_FAMILIES.length : 0;

  const rotated = OPERATOR_FAMILIES
    .slice(offset)
    .concat(OPERATOR_FAMILIES.slice(0, offset));

  const foundation =
    offset % 2 === 0 ? "pivot_rotation" : "prefix_pivot_rotation";

  return uniqueStrings([
    foundation,
    rotated[0],
    rotated[1],
    rotated[2]
  ]);
}

function computeIntentSeed(intent) {
  const proposal = intent?.proposal || {};
  const parts = [];

  parts.push(proposal.id || proposal.proposalId || "");
  parts.push(proposal.proposalClass || proposal.class || "");

  const direction = intent?.movement?.direction;

  if (Array.isArray(direction)) {
    parts.push(
      direction
        .map((value) =>
          Number.isFinite(value) ? String(Math.round(value * 1000)) : "0"
        )
        .join(",")
    );
  }

  return stableHash(parts.join("|"));
}

/**
 * Operators
 */

function generatePivotVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const pivotOrder = buildPivotOrder(path.length, intent);
  const selectedPivots = selectBroadPivotWindow(pivotOrder);

  for (const pivotIndex of selectedPivots) {
    for (const rotation of [-1, 1]) {
      const mutatedPath = tryPivotRotation(path, pivotIndex, rotation);

      if (!mutatedPath) {
        continue;
      }

      pushVariant(variants, {
        candidate,
        path: mutatedPath,
        intent,
        operator: "pivot_rotation",
        meta: {
          pivotIndex,
          rotation
        }
      });
    }
  }

  return variants;
}

function generatePrefixPivotVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const pivotOrder = buildPivotOrder(path.length, intent);
  const selectedPivots = selectBroadPivotWindow(pivotOrder);

  for (const pivotIndex of selectedPivots) {
    for (const rotation of [-1, 1]) {
      const mutatedPath = tryPrefixPivotRotation(path, pivotIndex, rotation);

      if (!mutatedPath) {
        continue;
      }

      pushVariant(variants, {
        candidate,
        path: mutatedPath,
        intent,
        operator: "prefix_pivot_rotation",
        meta: {
          pivotIndex,
          rotation
        }
      });
    }
  }

  return variants;
}

function generateContactSeekingPivotVariants(candidate, intent, sourceMetrics) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const pivotOrder = buildPivotOrder(path.length, intent);
  const contactRelevant = buildContactRelevantPivotIndices(candidate);
  const broad = selectBroadPivotWindow(pivotOrder);
  const selectedPivots = uniqueNumbers([
    ...contactRelevant,
    ...broad
  ]).filter((index) => pivotOrder.includes(index));

  for (const pivotIndex of selectedPivots) {
    for (const rotation of [-1, 1]) {
      const mutatedPath = tryPivotRotation(path, pivotIndex, rotation);

      if (!mutatedPath) {
        continue;
      }

      const metrics = computeHP2DPathMetrics({
        sequence: candidate.sequence,
        path: mutatedPath
      });

      if (metrics.valid !== true) {
        continue;
      }

      if (
        Number.isFinite(sourceMetrics?.energy) &&
        Number.isFinite(metrics.energy) &&
        metrics.energy >= sourceMetrics.energy
      ) {
        continue;
      }

      pushVariant(variants, {
        candidate,
        path: mutatedPath,
        intent,
        operator: "contact_seeking_pivot",
        meta: {
          pivotIndex,
          rotation,
          sourceEnergy: sourceMetrics.energy,
          sourceContacts: sourceMetrics.hhContacts,
          energy: metrics.energy,
          contacts: metrics.hhContacts
        }
      });
    }
  }

  return variants;
}

function generateContactPreservingPivotVariants(candidate, intent, sourceMetrics) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const sourceContacts = computeHHContactPairs(candidate.sequence, path);
  const pivotOrder = buildPivotOrder(path.length, intent);
  const contactRelevant = buildContactRelevantPivotIndices(candidate);
  const broad = selectBroadPivotWindow(pivotOrder);
  const selectedPivots = uniqueNumbers([
    ...contactRelevant,
    ...broad
  ]).filter((index) => pivotOrder.includes(index));

  for (const pivotIndex of selectedPivots) {
    for (const rotation of [-1, 1]) {
      const mutatedPath = tryPivotRotation(path, pivotIndex, rotation);

      if (!mutatedPath) {
        continue;
      }

      const metrics = computeHP2DPathMetrics({
        sequence: candidate.sequence,
        path: mutatedPath
      });

      if (metrics.valid !== true) {
        continue;
      }

      const nextContacts = computeHHContactPairs(candidate.sequence, mutatedPath);
      const preservedContacts = countPreservedContacts(
        sourceContacts,
        nextContacts
      );

      const keepsQuality =
        Number.isFinite(sourceMetrics?.energy) &&
        Number.isFinite(metrics.energy) &&
        metrics.energy <= sourceMetrics.energy;

      const preservesAny =
        preservedContacts > 0 ||
        metrics.hhContacts >= sourceMetrics.hhContacts;

      if (!keepsQuality || !preservesAny) {
        continue;
      }

      pushVariant(variants, {
        candidate,
        path: mutatedPath,
        intent,
        operator: "contact_preserving_pivot",
        meta: {
          pivotIndex,
          rotation,
          preservedContacts,
          sourceEnergy: sourceMetrics.energy,
          sourceContacts: sourceMetrics.hhContacts,
          energy: metrics.energy,
          contacts: metrics.hhContacts
        }
      });
    }
  }

  return variants;
}

function generateCornerFlipVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const order = buildInternalIndexOrder(path.length, intent);
  const selected = selectBroadIndexWindow(order);

  for (const index of selected) {
    const mutatedPath = tryCornerFlip(path, index);

    if (!mutatedPath) {
      continue;
    }

    pushVariant(variants, {
      candidate,
      path: mutatedPath,
      intent,
      operator: "corner_flip",
      meta: {
        index
      }
    });
  }

  return variants;
}

function generateCrankshaftVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 4) {
    return variants;
  }

  const order = buildCrankshaftOrder(path.length, intent);
  const selected = selectBroadIndexWindow(order);

  for (const segmentStart of selected) {
    const mutatedPath = tryCrankshaftMove(path, segmentStart);

    if (!mutatedPath) {
      continue;
    }

    pushVariant(variants, {
      candidate,
      path: mutatedPath,
      intent,
      operator: "crankshaft_move",
      meta: {
        segmentStart,
        segmentEnd: segmentStart + 1
      }
    });
  }

  return variants;
}

function generateEndRotationVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 2) {
    return variants;
  }

  for (const mutatedPath of tryEndpointRotations(path, "start")) {
    pushVariant(variants, {
      candidate,
      path: mutatedPath,
      intent,
      operator: "end_rotation",
      meta: {
        end: "start"
      }
    });
  }

  for (const mutatedPath of tryEndpointRotations(path, "end")) {
    pushVariant(variants, {
      candidate,
      path: mutatedPath,
      intent,
      operator: "end_rotation",
      meta: {
        end: "end"
      }
    });
  }

  return variants;
}

function generatePullMoveLightVariants(candidate, intent) {
  const variants = [];
  const path = candidate.path;

  if (!Array.isArray(path) || path.length < 3) {
    return variants;
  }

  const order = buildInternalIndexOrder(path.length, intent);
  const selected = selectBroadIndexWindow(order);

  for (const index of selected) {
    const mutatedPaths = tryPullMoveLight(path, index);

    for (const mutatedPath of mutatedPaths) {
      pushVariant(variants, {
        candidate,
        path: mutatedPath,
        intent,
        operator: "pull_move_light",
        meta: {
          index
        }
      });
    }
  }

  return variants;
}

/**
 * Move implementations
 */

function tryPivotRotation(path, pivotIndex, rotation) {
  if (pivotIndex <= 0 || pivotIndex >= path.length - 1) {
    return null;
  }

  const pivot = path[pivotIndex];
  const nextPath = path.map(clonePoint);

  for (let i = pivotIndex + 1; i < nextPath.length; i += 1) {
    const dx = path[i].x - pivot.x;
    const dy = path[i].y - pivot.y;

    nextPath[i] =
      rotation === 1
        ? { x: pivot.x - dy, y: pivot.y + dx }
        : { x: pivot.x + dy, y: pivot.y - dx };
  }

  if (samePath(path, nextPath)) {
    return null;
  }

  return isValidHP2DPath(nextPath) ? nextPath : null;
}

function tryPrefixPivotRotation(path, pivotIndex, rotation) {
  if (pivotIndex <= 0 || pivotIndex >= path.length - 1) {
    return null;
  }

  const pivot = path[pivotIndex];
  const nextPath = path.map(clonePoint);

  for (let i = 0; i < pivotIndex; i += 1) {
    const dx = path[i].x - pivot.x;
    const dy = path[i].y - pivot.y;

    nextPath[i] =
      rotation === 1
        ? { x: pivot.x - dy, y: pivot.y + dx }
        : { x: pivot.x + dy, y: pivot.y - dx };
  }

  if (samePath(path, nextPath)) {
    return null;
  }

  return isValidHP2DPath(nextPath) ? nextPath : null;
}

function tryCornerFlip(path, index) {
  if (index <= 0 || index >= path.length - 1) {
    return null;
  }

  const prev = path[index - 1];
  const curr = path[index];
  const next = path[index + 1];

  if (manhattanDistance(prev, next) !== 2) {
    return null;
  }

  if (prev.x === next.x || prev.y === next.y) {
    return null;
  }

  const alternatives = [
    { x: prev.x, y: next.y },
    { x: next.x, y: prev.y }
  ];

  for (const point of alternatives) {
    if (point.x === curr.x && point.y === curr.y) {
      continue;
    }

    const nextPath = path.map(clonePoint);
    nextPath[index] = point;

    if (samePath(path, nextPath)) {
      continue;
    }

    if (isValidHP2DPath(nextPath)) {
      return nextPath;
    }
  }

  return null;
}

function tryCrankshaftMove(path, segmentStart) {
  const i = segmentStart;

  if (i <= 0 || i + 2 >= path.length) {
    return null;
  }

  const a = path[i - 1];
  const b = path[i];
  const c = path[i + 1];
  const d = path[i + 2];

  /**
   * Conservative square-lattice crankshaft:
   * Only handle the clean plaquette case where anchors a and d are neighbors.
   * The two middle points are moved to the opposite side of the anchor edge.
   */
  if (manhattanDistance(a, d) !== 1) {
    return null;
  }

  const candidates = buildSharedNeighborPairs(a, d);

  for (const pair of candidates) {
    const [nextB, nextC] = pair;

    if (
      (nextB.x === b.x && nextB.y === b.y && nextC.x === c.x && nextC.y === c.y) ||
      (nextB.x === c.x && nextB.y === c.y && nextC.x === b.x && nextC.y === b.y)
    ) {
      continue;
    }

    const nextPath = path.map(clonePoint);
    nextPath[i] = nextB;
    nextPath[i + 1] = nextC;

    if (samePath(path, nextPath)) {
      continue;
    }

    if (isValidHP2DPath(nextPath)) {
      return nextPath;
    }
  }

  return null;
}

function buildSharedNeighborPairs(a, d) {
  const aNeighbors = getLatticeNeighbors(a);
  const dNeighbors = getLatticeNeighbors(d);
  const shared = [];

  for (const p of aNeighbors) {
    for (const q of dNeighbors) {
      if (p.x === q.x && p.y === q.y) {
        shared.push(p);
      }
    }
  }

  const pairs = [];

  for (let i = 0; i < shared.length; i += 1) {
    for (let j = 0; j < shared.length; j += 1) {
      if (i === j) {
        continue;
      }

      if (manhattanDistance(shared[i], shared[j]) !== 1) {
        continue;
      }

      pairs.push([shared[i], shared[j]]);
    }
  }

  return pairs;
}

function tryEndpointRotations(path, end) {
  const results = [];

  if (path.length < 2) {
    return results;
  }

  if (end === "start") {
    const anchor = path[1];
    const occupied = buildOccupiedSet(path, 0);

    for (const point of getLatticeNeighbors(anchor)) {
      if (occupied.has(pointKey(point))) {
        continue;
      }

      const nextPath = path.map(clonePoint);
      nextPath[0] = point;

      if (!samePath(path, nextPath) && isValidHP2DPath(nextPath)) {
        results.push(nextPath);
      }
    }

    return results;
  }

  const lastIndex = path.length - 1;
  const anchor = path[lastIndex - 1];
  const occupied = buildOccupiedSet(path, lastIndex);

  for (const point of getLatticeNeighbors(anchor)) {
    if (occupied.has(pointKey(point))) {
      continue;
    }

    const nextPath = path.map(clonePoint);
    nextPath[lastIndex] = point;

    if (!samePath(path, nextPath) && isValidHP2DPath(nextPath)) {
      results.push(nextPath);
    }
  }

  return results;
}

function tryPullMoveLight(path, index) {
  const results = [];

  if (index <= 0 || index >= path.length - 1) {
    return results;
  }

  const prev = path[index - 1];
  const next = path[index + 1];
  const occupied = buildOccupiedSet(path, index);

  for (const point of getLatticeNeighbors(prev)) {
    if (occupied.has(pointKey(point))) {
      continue;
    }

    if (manhattanDistance(point, next) !== 1) {
      continue;
    }

    const nextPath = path.map(clonePoint);
    nextPath[index] = point;

    if (!samePath(path, nextPath) && isValidHP2DPath(nextPath)) {
      results.push(nextPath);
    }
  }

  return results;
}

/**
 * Ranking
 */

function rankCandidateRows(params = {}) {
  const { sourceCandidate, candidates } = params;

  const sourceContacts = computeHHContactPairs(
    sourceCandidate.sequence,
    sourceCandidate.path
  );

  const rows = candidates.map((candidate, index) => {
    const metrics = computeHP2DPathMetrics({
      sequence: candidate.sequence,
      path: candidate.path
    });

    const contacts = computeHHContactPairs(candidate.sequence, candidate.path);
    const preservedContacts = countPreservedContacts(sourceContacts, contacts);

    return {
      index,
      candidate,
      metrics,
      preservedContacts,
      distanceFromSource: computePathDistance(
        sourceCandidate.path,
        candidate.path
      ),
      operator: candidate?.meta?.realization?.operator || "unknown",
      operatorPriority: getOperatorPriority(
        candidate?.meta?.realization?.operator
      )
    };
  });

  rows.sort(compareVariantRows);
  return rows;
}

function compareVariantRows(a, b) {
  if (a.metrics.valid === true && b.metrics.valid !== true) {
    return -1;
  }

  if (a.metrics.valid !== true && b.metrics.valid === true) {
    return 1;
  }

  if (a.metrics.energy !== b.metrics.energy) {
    return a.metrics.energy - b.metrics.energy;
  }

  if (a.metrics.hhContacts !== b.metrics.hhContacts) {
    return b.metrics.hhContacts - a.metrics.hhContacts;
  }

  if (a.preservedContacts !== b.preservedContacts) {
    return b.preservedContacts - a.preservedContacts;
  }

  if (a.operatorPriority !== b.operatorPriority) {
    return a.operatorPriority - b.operatorPriority;
  }

  if (a.distanceFromSource !== b.distanceFromSource) {
    return b.distanceFromSource - a.distanceFromSource;
  }

  return a.index - b.index;
}

function getOperatorPriority(operator) {
  switch (operator) {
    case "pivot_rotation":
      return 1;
    case "prefix_pivot_rotation":
      return 2;
    case "corner_flip":
      return 3;
    case "crankshaft_move":
      return 4;
    case "end_rotation":
      return 5;
    case "pull_move_light":
      return 6;
    case "contact_seeking_pivot":
      return 7;
    case "contact_preserving_pivot":
      return 8;
    default:
      return 99;
  }
}

/**
 * Selection/order helpers
 */

function buildPivotOrder(length, intent) {
  const indices = [];

  for (let i = 1; i < length - 1; i += 1) {
    indices.push(i);
  }

  return rotateIndicesByIntent(indices, intent);
}

function buildInternalIndexOrder(length, intent) {
  const indices = [];

  for (let i = 1; i < length - 1; i += 1) {
    indices.push(i);
  }

  return rotateIndicesByIntent(indices, intent);
}

function buildCrankshaftOrder(length, intent) {
  const indices = [];

  for (let i = 1; i < length - 2; i += 1) {
    indices.push(i);
  }

  return rotateIndicesByIntent(indices, intent);
}

function rotateIndicesByIntent(indices, intent) {
  if (!Array.isArray(indices) || indices.length === 0) {
    return [];
  }

  const seed = computeIntentSeed(intent);
  const offset = seed % indices.length;

  return indices.slice(offset).concat(indices.slice(0, offset));
}

function selectBroadPivotWindow(indices) {
  if (!Array.isArray(indices) || indices.length === 0) {
    return [];
  }

  const sqrtWindow = Math.ceil(Math.sqrt(indices.length));
  const halfWindow = Math.ceil(indices.length / 2);
  const windowSize = Math.max(1, Math.min(indices.length, halfWindow, sqrtWindow + 8));

  return indices.slice(0, windowSize);
}

function selectBroadIndexWindow(indices) {
  if (!Array.isArray(indices) || indices.length === 0) {
    return [];
  }

  const sqrtWindow = Math.ceil(Math.sqrt(indices.length));
  const thirdWindow = Math.ceil(indices.length / 3);
  const windowSize = Math.max(1, Math.min(indices.length, thirdWindow, sqrtWindow + 4));

  return indices.slice(0, windowSize);
}

function buildContactRelevantPivotIndices(candidate) {
  const contacts = computeHHContactPairs(candidate.sequence, candidate.path);
  const result = [];

  for (const contact of contacts) {
    const [aRaw, bRaw] = contact.split(":");
    const a = Number(aRaw);
    const b = Number(bRaw);

    if (!Number.isInteger(a) || !Number.isInteger(b)) {
      continue;
    }

    for (const index of [a - 1, a, a + 1, b - 1, b, b + 1]) {
      if (index > 0 && index < candidate.path.length - 1) {
        result.push(index);
      }
    }
  }

  return uniqueNumbers(result);
}

/**
 * Candidate construction
 */

function pushVariant(variants, params = {}) {
  const variant = createVariantCandidate(params);

  if (variant.valid !== true) {
    return;
  }

  variants.push(variant);
}

function createVariantCandidate(params = {}) {
  const { candidate, path, intent, operator, meta = {} } = params;

  const metrics = computeHP2DPathMetrics({
    sequence: candidate.sequence,
    path
  });

  return createCandidate({
    sequence: candidate.sequence,
    path,
    energy: metrics.energy,
    contacts: metrics.hhContacts,
    valid: metrics.valid,
    violations: metrics.valid ? [] : ["invalid_hp2d_path"],
    source: "hp2d_problem_realizer",
    meta: {
      ...(isPlainObject(candidate.meta) ? cloneValue(candidate.meta) : {}),
      realization: {
        operator,
        proposalId:
          intent?.proposal?.id ||
          intent?.proposal?.proposalId ||
          null,
        proposalClass:
          intent?.proposal?.proposalClass ||
          intent?.proposal?.class ||
          null,
        sourcePointId:
          intent?.sourcePointId ||
          intent?.proposal?.sourcePointId ||
          intent?.proposal?.sourceId ||
          null,
        ...meta
      }
    }
  });
}

function normalizeCandidate(candidate, problem) {
  if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) {
    throw new Error("hp2dProblemRealizer requires sourceCandidate object");
  }

  const sequence =
    typeof candidate.sequence === "string" && candidate.sequence.trim() !== ""
      ? candidate.sequence.trim().toUpperCase()
      : typeof problem?.sequence === "string"
        ? problem.sequence.trim().toUpperCase()
        : null;

  if (!sequence || !/^[HP]+$/.test(sequence)) {
    throw new Error("hp2dProblemRealizer requires valid HP sequence");
  }

  const path = normalizePath(candidate.path, sequence.length);
  const metrics = computeHP2DPathMetrics({ sequence, path });

  return createCandidate({
    sequence,
    path,
    energy: Number.isFinite(candidate.energy)
      ? candidate.energy
      : metrics.energy,
    contacts: Number.isFinite(candidate.contacts)
      ? candidate.contacts
      : metrics.hhContacts,
    valid:
      typeof candidate.valid === "boolean"
        ? candidate.valid
        : metrics.valid,
    violations: Array.isArray(candidate.violations)
      ? candidate.violations
      : metrics.valid
        ? []
        : ["invalid_hp2d_path"],
    source: candidate.source || "source_problem_candidate",
    meta: candidate.meta
  });
}

function createCandidate(params = {}) {
  const sequence = params.sequence;
  const path = normalizePath(params.path, sequence.length);

  const metrics = computeHP2DPathMetrics({
    sequence,
    path
  });

  const valid =
    typeof params.valid === "boolean" ? params.valid : metrics.valid;

  const energy = Number.isFinite(params.energy)
    ? normalizeNegativeZero(params.energy)
    : normalizeNegativeZero(metrics.energy);

  const contacts = Number.isFinite(params.contacts)
    ? params.contacts
    : metrics.hhContacts;

  return {
    kind: "hp2d_candidate",
    sequence,
    path,
    energy,
    contacts,
    hhContacts: contacts,
    primaryValue: energy,
    valid,
    violations: Array.isArray(params.violations) ? params.violations.slice() : [],
    source: params.source || "hp2d_problem_realizer",
    meta: isPlainObject(params.meta) ? cloneValue(params.meta) : {},
    evaluation: {
      valid,
      objective: "minimize_energy",
      objectiveDirection: "minimize",
      primaryValue: energy,
      secondaryValue: contacts,
      energy,
      contacts,
      hhContacts: contacts,
      metrics: {
        energy,
        contacts,
        hhContacts: contacts
      },
      summary: {
        energy,
        contacts
      }
    }
  };
}

function cloneCandidate(candidate) {
  return createCandidate({
    sequence: candidate.sequence,
    path: candidate.path,
    energy: candidate.energy,
    contacts: candidate.contacts,
    valid: candidate.valid,
    violations: candidate.violations,
    source: candidate.source,
    meta: candidate.meta
  });
}

/**
 * Metrics / validation
 */

function computeHP2DPathMetrics(params = {}) {
  const sequence =
    typeof params.sequence === "string" ? params.sequence : "";

  const path = Array.isArray(params.path) ? params.path : [];

  if (!sequence || !Array.isArray(path) || sequence.length !== path.length) {
    return {
      valid: false,
      hhContacts: 0,
      energy: Number.POSITIVE_INFINITY
    };
  }

  if (!isValidHP2DPath(path)) {
    return {
      valid: false,
      hhContacts: 0,
      energy: Number.POSITIVE_INFINITY
    };
  }

  const hhContacts = computeHHContactPairs(sequence, path).size;

  return {
    valid: true,
    hhContacts,
    energy: normalizeNegativeZero(-hhContacts)
  };
}

function computeHHContactPairs(sequence, path) {
  const contacts = new Set();

  for (let i = 0; i < path.length; i += 1) {
    if (sequence[i] !== "H") {
      continue;
    }

    for (let j = i + 2; j < path.length; j += 1) {
      if (sequence[j] !== "H") {
        continue;
      }

      if (Math.abs(i - j) === 1) {
        continue;
      }

      if (manhattanDistance(path[i], path[j]) === 1) {
        contacts.add(`${i}:${j}`);
      }
    }
  }

  return contacts;
}

function countPreservedContacts(sourceContacts, nextContacts) {
  if (!(sourceContacts instanceof Set) || !(nextContacts instanceof Set)) {
    return 0;
  }

  let count = 0;

  for (const contact of sourceContacts) {
    if (nextContacts.has(contact)) {
      count += 1;
    }
  }

  return count;
}

function isValidHP2DPath(path) {
  if (!Array.isArray(path) || path.length === 0) {
    return false;
  }

  const occupied = new Set();

  for (let i = 0; i < path.length; i += 1) {
    const point = path[i];

    if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y)) {
      return false;
    }

    const key = pointKey(point);

    if (occupied.has(key)) {
      return false;
    }

    occupied.add(key);

    if (i > 0 && manhattanDistance(path[i - 1], point) !== 1) {
      return false;
    }
  }

  return true;
}

/**
 * Debug
 */

function logHP2DRealizerQuality(params = {}) {
  const { intent, baseCandidate, candidates } = params;

  const sourceMetrics = computeHP2DPathMetrics({
    sequence: baseCandidate.sequence,
    path: baseCandidate.path
  });

  const rows = Array.isArray(candidates)
    ? candidates.map((candidate) => ({
        candidate,
        metrics: computeHP2DPathMetrics({
          sequence: candidate.sequence,
          path: candidate.path
        })
      }))
    : [];

  const best = selectBestVariantRow(rows);
  const bestMeta =
    best?.candidate?.meta?.realization &&
    typeof best.candidate.meta.realization === "object"
      ? best.candidate.meta.realization
      : {};

  const firstDebug =
    rows[0]?.candidate?.__realizationDebug &&
    typeof rows[0].candidate.__realizationDebug === "object"
      ? rows[0].candidate.__realizationDebug
      : {};

  const operatorStats = buildOperatorStats(rows);

  const record = {
    kind: "hp2d_realizer_quality",
    proposalId:
      intent?.proposal?.id ||
      intent?.proposal?.proposalId ||
      null,
    sourcePointId:
      intent?.sourcePointId ||
      intent?.proposal?.sourcePointId ||
      intent?.proposal?.sourceId ||
      null,
    sourcePathKey: shortPathKey(baseCandidate.path),
    sourceEnergy: normalizeNegativeZero(sourceMetrics.energy),
    sourceContacts: sourceMetrics.hhContacts,
    operatorFamilies: firstDebug.operatorFamilies || null,
    variantCount: rows.length,
    rawVariantCount: firstDebug.rawVariantCount ?? null,
    dedupedVariantCount: firstDebug.dedupedVariantCount ?? null,
    bestPathKey: best?.candidate?.path ? shortPathKey(best.candidate.path) : null,
    bestEnergy: normalizeNegativeZero(best?.metrics?.energy ?? null),
    bestContacts: best?.metrics?.hhContacts ?? null,
    bestOperator: bestMeta.operator || null,
    operatorStats
  };

  const isInteresting =
    DEBUG_REALIZATION_PLATEAU ||
    (
      Number.isFinite(record.bestEnergy) &&
      Number.isFinite(record.sourceEnergy) &&
      record.bestEnergy < record.sourceEnergy
    ) ||
    (
      Number.isFinite(record.bestEnergy) &&
      record.bestEnergy <= -3
    );

  if (isInteresting) {
    console.log(`[HP2D_REALIZER] ${JSON.stringify(record)}`);
  }
}

function buildOperatorStats(rows) {
  const stats = {};

  if (!Array.isArray(rows)) {
    return stats;
  }

  for (const row of rows) {
    const operator =
      row?.candidate?.meta?.realization?.operator || "unknown";

    if (!stats[operator]) {
      stats[operator] = {
        count: 0,
        bestEnergy: null,
        bestContacts: null
      };
    }

    stats[operator].count += 1;

    const energy = row?.metrics?.energy;
    const contacts = row?.metrics?.hhContacts;

    if (
      Number.isFinite(energy) &&
      (
        stats[operator].bestEnergy === null ||
        energy < stats[operator].bestEnergy
      )
    ) {
      stats[operator].bestEnergy = normalizeNegativeZero(energy);
      stats[operator].bestContacts = Number.isFinite(contacts)
        ? contacts
        : null;
    }
  }

  return stats;
}

function selectBestVariantRow(rows) {
  if (!Array.isArray(rows) || rows.length === 0) {
    return null;
  }

  let best = null;

  for (const row of rows) {
    if (!row || !row.metrics) {
      continue;
    }

    if (!best) {
      best = row;
      continue;
    }

    if (row.metrics.energy < best.metrics.energy) {
      best = row;
      continue;
    }

    if (
      row.metrics.energy === best.metrics.energy &&
      row.metrics.hhContacts > best.metrics.hhContacts
    ) {
      best = row;
    }
  }

  return best;
}

function attachRealizationDebug(candidate, debugInfo) {
  if (!DEBUG_REALIZATION_PLATEAU && !DEBUG_HP2D_REALIZER) {
    return candidate;
  }

  if (!candidate || typeof candidate !== "object") {
    return candidate;
  }

  Object.defineProperty(candidate, "__realizationDebug", {
    value: debugInfo,
    enumerable: false,
    configurable: true
  });

  return candidate;
}

/**
 * Low-level helpers
 */

function normalizePath(path, expectedLength) {
  if (!Array.isArray(path)) {
    throw new Error("hp2dProblemRealizer requires sourceCandidate.path array");
  }

  if (path.length !== expectedLength) {
    throw new Error(
      `hp2dProblemRealizer path length must match sequence length (${expectedLength})`
    );
  }

  return path.map((point, index) => normalizePoint(point, index));
}

function normalizePoint(point, index) {
  if (!point || typeof point !== "object" || Array.isArray(point)) {
    throw new Error(`hp2d path point at index ${index} must be object`);
  }

  if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) {
    throw new Error(
      `hp2d path point at index ${index} requires finite numeric x and y`
    );
  }

  return {
    x: point.x,
    y: point.y
  };
}

function buildOccupiedSet(path, excludedIndex = null) {
  const occupied = new Set();

  for (let i = 0; i < path.length; i += 1) {
    if (i === excludedIndex) {
      continue;
    }

    occupied.add(pointKey(path[i]));
  }

  return occupied;
}

function getLatticeNeighbors(point) {
  return [
    { x: point.x + 1, y: point.y },
    { x: point.x - 1, y: point.y },
    { x: point.x, y: point.y + 1 },
    { x: point.x, y: point.y - 1 }
  ];
}

function manhattanDistance(a, b) {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
}

function computePathDistance(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
    return 0;
  }

  let sum = 0;

  for (let i = 0; i < a.length; i += 1) {
    sum += manhattanDistance(a[i], b[i]);
  }

  return sum;
}

function samePath(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
    return false;
  }

  for (let i = 0; i < a.length; i += 1) {
    if (a[i]?.x !== b[i]?.x || a[i]?.y !== b[i]?.y) {
      return false;
    }
  }

  return true;
}

function pointKey(point) {
  return `${point.x}:${point.y}`;
}

function pathKey(path) {
  return path.map((point) => pointKey(point)).join("|");
}

function shortPathKey(path) {
  if (!Array.isArray(path)) {
    return null;
  }

  return `n${path.length}:${stableHash(pathKey(path)).toString(16).padStart(8, "0")}`;
}

function dedupeCandidates(candidates) {
  const seen = new Set();
  const result = [];

  if (!Array.isArray(candidates)) {
    return result;
  }

  for (const candidate of candidates) {
    if (!candidate || !Array.isArray(candidate.path)) {
      continue;
    }

    const key = pathKey(candidate.path);

    if (seen.has(key)) {
      continue;
    }

    seen.add(key);
    result.push(candidate);
  }

  return result;
}

function uniqueStrings(values) {
  const seen = new Set();
  const result = [];

  for (const value of values) {
    if (typeof value !== "string" || value.length === 0) {
      continue;
    }

    if (seen.has(value)) {
      continue;
    }

    seen.add(value);
    result.push(value);
  }

  return result;
}

function uniqueNumbers(values) {
  const seen = new Set();
  const result = [];

  for (const value of values) {
    if (!Number.isInteger(value)) {
      continue;
    }

    if (seen.has(value)) {
      continue;
    }

    seen.add(value);
    result.push(value);
  }

  return result;
}

function validateInputs(intent, sourceCandidate) {
  if (!intent || typeof intent !== "object") {
    throw new Error("hp2dProblemRealizer requires intent");
  }

  if (!sourceCandidate || typeof sourceCandidate !== "object") {
    throw new Error("hp2dProblemRealizer requires sourceCandidate");
  }
}

function clonePoint(point) {
  return {
    x: point.x,
    y: point.y
  };
}

function cloneValue(value) {
  if (Array.isArray(value)) {
    return value.map(cloneValue);
  }

  if (isPlainObject(value)) {
    const out = {};

    for (const key of Object.keys(value)) {
      out[key] = cloneValue(value[key]);
    }

    return out;
  }

  return value;
}

function normalizeNegativeZero(value) {
  return Object.is(value, -0) ? 0 : value;
}

function stableHash(value) {
  const text = String(value || "");
  let hash = 2166136261;

  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }

  return hash >>> 0;
}

function readPositiveIntegerEnv(name, fallback) {
  const raw = process.env[name];
  const parsed = Number(raw);

  if (!Number.isInteger(parsed) || parsed <= 0) {
    return fallback;
  }

  return parsed;
}

function isPlainObject(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

module.exports = {
  createHP2DProblemRealizer
};
