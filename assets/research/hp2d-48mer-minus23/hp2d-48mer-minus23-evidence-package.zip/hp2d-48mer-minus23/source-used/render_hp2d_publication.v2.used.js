#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function fail(message) {
  console.error(message);
  process.exit(1);
}

function getArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith('--')) continue;
    const key = token.slice(2);
    const next = argv[i + 1];
    if (!next || next.startsWith('--')) {
      out[key] = true;
    } else {
      out[key] = next;
      i += 1;
    }
  }
  return out;
}

function normalizeNegativeZero(value) {
  return Object.is(value, -0) ? 0 : value;
}

function sha256String(input) {
  return crypto.createHash('sha256').update(input).digest('hex');
}

function sha256File(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function getFirstDefined(candidates) {
  for (const candidate of candidates) {
    if (candidate !== undefined && candidate !== null) return candidate;
  }
  return undefined;
}

function extractSequence(root) {
  const sequence = getFirstDefined([
    root.sequence,
    root.problem?.sequence,
    root.display?.sequence,
    root.hp2dFold?.sequence,
    root.fold?.sequence,
    root.artifact?.sequence,
  ]);

  if (typeof sequence !== 'string' || !/^[HP]+$/i.test(sequence)) {
    fail('Could not extract a valid HP sequence from JSON artifact.');
  }
  return sequence.toUpperCase();
}

function normalizeCoord(coord) {
  if (Array.isArray(coord) && coord.length >= 2) {
    return {
      x: normalizeNegativeZero(Number(coord[0])),
      y: normalizeNegativeZero(Number(coord[1])),
    };
  }
  if (coord && typeof coord === 'object' && 'x' in coord && 'y' in coord) {
    return {
      x: normalizeNegativeZero(Number(coord.x)),
      y: normalizeNegativeZero(Number(coord.y)),
    };
  }
  return null;
}

function extractCoords(root) {
  const raw = getFirstDefined([
    root.coords,
    root.display?.coords,
    root.hp2dFold?.coords,
    root.fold?.coords,
    root.artifact?.coords,
    root.problemCandidate?.path,
    root.path,
  ]);

  const coords = asArray(raw).map(normalizeCoord).filter(Boolean);
  if (!coords.length) fail('Could not extract coordinates from JSON artifact.');
  for (const c of coords) {
    if (!Number.isFinite(c.x) || !Number.isFinite(c.y)) {
      fail('Invalid coordinate encountered in JSON artifact.');
    }
  }
  return coords;
}

function extractReportedEnergy(root) {
  return getFirstDefined([
    root.energy,
    root.reportedEnergy,
    root.validatedEnergy,
    root.display?.energy,
    root.hp2dFold?.energy,
    root.fold?.energy,
    root.summary?.energy,
  ]);
}

function extractReportedContacts(root) {
  return getFirstDefined([
    root.contacts,
    root.reportedContacts,
    root.validatedContacts,
    root.hhContacts,
    root.display?.contacts,
    root.hp2dFold?.contacts,
    root.fold?.contacts,
    root.summary?.contacts,
  ]);
}

function extractCandidateId(root) {
  return getFirstDefined([
    root.candidateId,
    root.id,
    root.problemCandidate?.candidateId,
    root.problemCandidate?.id,
    root.provenance?.candidateId,
    root.display?.candidateId,
    root.hp2dFold?.candidateId,
  ]) || 'unknown_candidate';
}

function extractCanonicalHash(root) {
  return getFirstDefined([
    root.canonicalHash,
    root.hash,
    root.artifactHash,
    root.display?.canonicalHash,
    root.hp2dFold?.canonicalHash,
    root.fold?.canonicalHash,
  ]) || 'unknown';
}

function manhattan(a, b) {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
}

function validateFold(sequence, coords) {
  const violations = [];
  const seen = new Map();

  if (sequence.length !== coords.length) {
    violations.push(`sequence length ${sequence.length} != coords length ${coords.length}`);
  }

  coords.forEach((c, idx) => {
    const key = `${c.x},${c.y}`;
    if (seen.has(key)) {
      violations.push(`overlap at index ${idx} with index ${seen.get(key)} on ${key}`);
    } else {
      seen.set(key, idx);
    }
  });

  for (let i = 1; i < coords.length; i++) {
    if (manhattan(coords[i - 1], coords[i]) !== 1) {
      violations.push(`backbone break between ${i - 1} and ${i}`);
    }
  }

  const contacts = [];
  for (let i = 0; i < coords.length; i++) {
    if (sequence[i] !== 'H') continue;
    for (let j = i + 2; j < coords.length; j++) {
      if (sequence[j] !== 'H') continue;
      if (Math.abs(i - j) === 1) continue;
      if (manhattan(coords[i], coords[j]) === 1) contacts.push([i, j]);
    }
  }

  return {
    valid: violations.length === 0,
    violations,
    contacts,
    hhContacts: contacts.length,
    energy: -contacts.length,
  };
}

function boundsOf(coords) {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const c of coords) {
    minX = Math.min(minX, c.x);
    minY = Math.min(minY, c.y);
    maxX = Math.max(maxX, c.x);
    maxY = Math.max(maxY, c.y);
  }
  return { minX, minY, maxX, maxY, width: maxX - minX + 1, height: maxY - minY + 1 };
}

function esc(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function shortHash(h, n = 18) {
  const s = String(h || 'unknown');
  return s.length > n ? `${s.slice(0, n)}…` : s;
}

function makeConfig(mode) {
  if (mode === 'evidence') {
    return {
      mode,
      width: 1800,
      height: 1400,
      titleY: 72,
      subtitleY: 120,
      titleSize: 34,
      subtitleSize: 19,
      topArea: 170,
      bottomArea: 180,
      sidePad: 120,
      foldFill: 0.76,
      showIndices: true,
      showOnlyHIndices: true,
      footerSize: 13,
      nodeRadiusBase: 29,
    };
  }
  return {
    mode: 'hero',
    width: 1600,
    height: 1600,
    titleY: 76,
    subtitleY: 126,
    titleSize: 38,
    subtitleSize: 20,
    topArea: 175,
    bottomArea: 170,
    sidePad: 110,
    foldFill: 0.87,
    showIndices: false,
    showOnlyHIndices: false,
    footerSize: 18,
    nodeRadiusBase: 31,
  };
}

function renderLegend(width, height) {
  const y = height - 92;
  const x1 = 86;
  const x2 = x1 + 165;
  const x3 = x2 + 235;
  return `
    <g font-family="Inter, Arial, sans-serif" font-size="16" fill="#334155">
      <circle cx="${x1}" cy="${y}" r="12" fill="#0F172A" stroke="#2563EB" stroke-width="3" />
      <text x="${x1 + 24}" y="${y + 6}">H monomer</text>

      <circle cx="${x2}" cy="${y}" r="12" fill="#F8FAFC" stroke="#94A3B8" stroke-width="3" />
      <text x="${x2 + 24}" y="${y + 6}">P monomer</text>

      <line x1="${x3}" y1="${y}" x2="${x3 + 70}" y2="${y}" stroke="#7BA4E8" stroke-width="4" stroke-dasharray="8 8" />
      <text x="${x3 + 88}" y="${y + 6}">non-consecutive H-H contact</text>
    </g>
  `;
}

function renderFoldSvg(data, config) {
  const { sequence, coords, validation, candidateId, canonicalHash, jsonSha256, computedCoordinateHash } = data;
  const width = config.width;
  const height = config.height;
  const bounds = boundsOf(coords);

  const usableWidth = width - config.sidePad * 2;
  const usableHeight = height - config.topArea - config.bottomArea;
  const cellSize = Math.min(
    usableWidth / Math.max(bounds.width, 1),
    usableHeight / Math.max(bounds.height, 1)
  ) * config.foldFill;

  const step = cellSize;
  const layoutWidth = (bounds.width - 1) * step;
  const layoutHeight = (bounds.height - 1) * step;
  const originX = (width - layoutWidth) / 2;
  const originY = config.topArea + (usableHeight - layoutHeight) / 2;
  const radius = Math.max(20, Math.min(config.nodeRadiusBase, step * 0.30));

  function sx(x) { return originX + (x - bounds.minX) * step; }
  function sy(y) { return originY + (bounds.maxY - y) * step; }

  const gridDots = [];
  for (let gx = bounds.minX - 1; gx <= bounds.maxX + 1; gx++) {
    for (let gy = bounds.minY - 1; gy <= bounds.maxY + 1; gy++) {
      gridDots.push(`<circle cx="${sx(gx)}" cy="${sy(gy)}" r="1.5" fill="#E2E8F0" />`);
    }
  }

  const contactLines = validation.contacts.map(([a, b]) => {
    return `<line x1="${sx(coords[a].x)}" y1="${sy(coords[a].y)}" x2="${sx(coords[b].x)}" y2="${sy(coords[b].y)}" stroke="#7BA4E8" stroke-width="4" stroke-dasharray="10 8" stroke-linecap="round" />`;
  });

  const backboneLines = [];
  for (let i = 1; i < coords.length; i++) {
    backboneLines.push(
      `<line x1="${sx(coords[i - 1].x)}" y1="${sy(coords[i - 1].y)}" x2="${sx(coords[i].x)}" y2="${sy(coords[i].y)}" stroke="#64748B" stroke-width="5" stroke-linecap="round" />`
    );
  }

  const nodes = coords.map((c, idx) => {
    const letter = sequence[idx];
    const isH = letter === 'H';
    const cx = sx(c.x);
    const cy = sy(c.y);
    const fill = isH ? '#0F172A' : '#F8FAFC';
    const stroke = isH ? '#2563EB' : '#94A3B8';
    const textFill = isH ? '#FFFFFF' : '#334155';

    let label = '';
    if (config.showIndices && (!config.showOnlyHIndices || isH)) {
      label = `<text x="${cx + radius * 0.55}" y="${cy - radius * 0.60}" font-family="Inter, Arial, sans-serif" font-size="11" fill="#64748B">${idx}</text>`;
    }

    return `
      <g>
        <circle cx="${cx}" cy="${cy}" r="${radius}" fill="${fill}" stroke="${stroke}" stroke-width="4" />
        <text x="${cx}" y="${cy + 6}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="22" font-weight="700" fill="${textFill}">${letter}</text>
        ${label}
      </g>
    `;
  });

  const title = 'HP 2D 48-mer folding result';
  const subtitle = `Energy ${validation.energy} | HH contacts ${validation.hhContacts} | MEVENTA Creative Runtime v10`;

  const footerLines = config.mode === 'hero'
    ? [
        'Valid fold | Independently revalidated from exported JSON artifact',
        `Candidate ${candidateId} | canonical hash ${shortHash(canonicalHash, 22)} | JSON SHA256 ${shortHash(jsonSha256, 22)}`,
      ]
    : [
        `Candidate: ${candidateId} | canonical hash: ${shortHash(canonicalHash, 22)} | JSON SHA256: ${shortHash(jsonSha256, 22)}`,
        `Independent coordinate validation: valid=${validation.valid}; violations=${validation.violations.length}; computed coordinate hash=${shortHash(computedCoordinateHash, 22)}`,
      ];

  const footerSvg = footerLines.map((line, i) => {
    const y = height - 26 - (footerLines.length - 1 - i) * 28;
    return `<text x="${width / 2}" y="${y}" text-anchor="middle" font-family="Menlo, Consolas, monospace" font-size="${config.footerSize}" fill="#475569">${esc(line)}</text>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(title)}">
  <rect width="100%" height="100%" fill="#FFFFFF" />
  <text x="${width / 2}" y="${config.titleY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${config.titleSize}" font-weight="800" fill="#0F172A">${esc(title)}</text>
  <text x="${width / 2}" y="${config.subtitleY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${config.subtitleSize}" font-weight="700" fill="#334155">${esc(subtitle)}</text>

  <g>
    ${gridDots.join('\n')}
  </g>
  <g>
    ${contactLines.join('\n')}
  </g>
  <g>
    ${backboneLines.join('\n')}
  </g>
  <g>
    ${nodes.join('\n')}
  </g>

  ${renderLegend(width, height)}
  ${footerSvg}
</svg>`;
}

function writeText(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, 'utf8');
}

function renderOneMode(root, inputPath, outDir, mode) {
  const sequence = extractSequence(root);
  const coords = extractCoords(root);
  const validation = validateFold(sequence, coords);
  const reportedEnergy = Number(extractReportedEnergy(root));
  const reportedContacts = Number(extractReportedContacts(root));

  if (!validation.valid) fail(`Validation failed for mode=${mode}: ${validation.violations.join('; ')}`);
  if (Number.isFinite(reportedEnergy) && reportedEnergy !== validation.energy) {
    fail(`Reported energy ${reportedEnergy} does not match computed energy ${validation.energy}.`);
  }
  if (Number.isFinite(reportedContacts) && reportedContacts !== validation.hhContacts) {
    fail(`Reported contacts ${reportedContacts} does not match computed contacts ${validation.hhContacts}.`);
  }
  if (validation.energy !== -23 || validation.hhContacts !== 23) {
    fail(`Expected validated energy -23 and contacts 23, got energy=${validation.energy}, contacts=${validation.hhContacts}.`);
  }

  const candidateId = extractCandidateId(root);
  const canonicalHash = extractCanonicalHash(root);
  const jsonSha256 = sha256File(inputPath);
  const computedCoordinateHash = sha256String(JSON.stringify(coords.map(c => [c.x, c.y])));

  const data = {
    sequence,
    coords,
    validation,
    candidateId,
    canonicalHash,
    jsonSha256,
    computedCoordinateHash,
  };

  const config = makeConfig(mode);
  const svg = renderFoldSvg(data, config);

  const base = `hp2d-48mer-minus23-${mode}`;
  const svgPath = path.join(outDir, `${base}.svg`);
  const captionPath = path.join(outDir, `${base}.caption.txt`);
  const validationPath = path.join(outDir, `${base}.validation.json`);

  writeText(svgPath, svg);
  writeText(captionPath, [
    'HP 2D 48-mer folding result',
    `Energy ${validation.energy} | HH contacts ${validation.hhContacts} | MEVENTA Creative Runtime v10`,
    `Candidate: ${candidateId}`,
    `Canonical artifact hash: ${canonicalHash}`,
    `JSON SHA256: ${jsonSha256}`,
    `Independent coordinate validation: valid=${validation.valid}; violations=${validation.violations.length}; computed coordinate hash=${computedCoordinateHash}`,
  ].join('\n'));
  writeText(validationPath, JSON.stringify({
    mode,
    candidateId,
    canonicalHash,
    jsonSha256,
    computedCoordinateHash,
    sequenceLength: sequence.length,
    coordsLength: coords.length,
    valid: validation.valid,
    violations: validation.violations,
    hhContacts: validation.hhContacts,
    energy: validation.energy,
    contacts: validation.contacts,
  }, null, 2));

  return {
    mode,
    svgPath,
    captionPath,
    validationPath,
    energy: validation.energy,
    contacts: validation.hhContacts,
    valid: validation.valid,
    jsonSha256,
    computedCoordinateHash,
  };
}

function main() {
  const args = getArgs(process.argv.slice(2));
  const inputPath = args.input || args.json;
  if (!inputPath) {
    fail('Usage: node render_hp2d_publication.js --input <artifact.json> --outdir <dir> [--mode hero|evidence|both]');
  }
  const outDir = args.outdir || args.output || path.join(process.cwd(), 'publication-render');
  const mode = String(args.mode || 'both').toLowerCase();
  const root = JSON.parse(fs.readFileSync(inputPath, 'utf8'));

  let results;
  if (mode === 'hero') {
    results = [renderOneMode(root, inputPath, outDir, 'hero')];
  } else if (mode === 'evidence') {
    results = [renderOneMode(root, inputPath, outDir, 'evidence')];
  } else if (mode === 'both' || mode === 'all') {
    results = [
      renderOneMode(root, inputPath, outDir, 'hero'),
      renderOneMode(root, inputPath, outDir, 'evidence'),
    ];
  } else {
    fail(`Unknown mode: ${mode}`);
  }

  console.log(JSON.stringify({
    exportStatus: 'ok',
    generated: results,
  }, null, 2));
}

main();
